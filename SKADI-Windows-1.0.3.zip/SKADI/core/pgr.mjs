import fs from 'node:fs'
import path from 'node:path'
import {under,readJson,writeJson,hashBytes,hashFile,fingerprint,equal,expect,copyNew,mkdir,requireThat} from './safe.mjs'
import {pgrLegacyOriginals} from './legacy.mjs'
import {recognizedStockCache,canonicalStockCache} from './pgr-cache-compat.mjs'

const source=f=>({exists:true,bytes:f.sourceBytes,sha256:f.sourceSha256})
const target=f=>({exists:true,bytes:f.bytes,sha256:f.sha256})
export class PgrAdapter {
  constructor({pack,previous=[],root,store,transaction,progress=()=>{}}){this.pack=pack;this.plan=pack.plan;this.previous=previous;this.root=root;this.store=store;this.tx=transaction;this.progress=progress;this.stateFile=under(transaction.home,'state.json');this.state=fs.existsSync(this.stateFile)?readJson(this.stateFile,32*1024*1024):null;this.previousItems=new Map();
    if(this.state)requireThat(this.state.format==='skadi-pgr-state-v1'&&this.state.gameId==='pgr'&&path.resolve(this.state.root)===path.resolve(root),'Повреждено состояние установки PGR.');
    const current=new Map(this.plan.files.map(f=>[f.path,f]));for(const p of previous)for(const f of p.plan.files||[])if(f.sourceSha256===current.get(f.path)?.sourceSha256){let a=this.previousItems.get(f.path);if(!a)this.previousItems.set(f.path,a=[]);a.push(target(f))}
  }
  accepts(f,actual){return equal(actual,source(f))||equal(actual,target(f))||(!actual.exists&&f.allowAbsent)||f.knownPrevious.some(p=>equal(actual,{exists:true,...p}))||(this.previousItems.get(f.path)||[]).some(x=>equal(actual,x))||recognizedStockCache(this.plan,f,actual)}
  original(f){const r=this.state?.originals?.[f.path];if(!r)return null;if(!r.exists)return f.allowAbsent?{exists:false}:null;if(!equal(r,source(f)))return null;const file=under(this.tx.home,'originals/'+r.sha256+'.uab');if(!fs.existsSync(file))return null;expect(file,r);return {...r,sourceFile:file}}
  async inspect(){
    const pending=this.tx.pending();let installed=0,clean=0,unknown=0,missing=0,stockCacheVariants=0;const problems=[],problemDetails=[]
    for(let i=0;i<this.plan.files.length;i++){const f=this.plan.files[i],actual=fingerprint(under(this.root,f.path));if(i%64===0)this.progress('Проверяю PGR: '+i+' / '+this.plan.files.length);if(equal(actual,target(f)))installed++;else if(equal(actual,source(f))||(!actual.exists&&f.allowAbsent))clean++;else if(recognizedStockCache(this.plan,f,actual)){canonicalStockCache(this.plan,f,actual);stockCacheVariants++;}else if(!this.accepts(f,actual)){unknown++;if(!actual.exists)missing++;if(problems.length<128){problems.push(f.path);problemDetails.push({path:f.path,actual,expectedSource:{...source(f),sha1:f.sourceSha1},expectedTranslation:target(f)});}}}
    const legacy=pgrLegacyOriginals(this.root,this.store,this.plan,this.previous.map(p=>p.plan));const originals=this.plan.files.filter(f=>this.original(f)||legacy.has(f.path)).length
    return {gameId:'pgr',checked:true,compatible:unknown===0,installed:installed===this.plan.files.length,canRollback:originals===this.plan.files.length,needsRecovery:!!pending,files:this.plan.files.length,targetFiles:installed,sourceFiles:clean,unknownFiles:unknown,missingFiles:missing,problemFiles:problems,problemDetails,stockCacheVariants,originals,packageHash:this.pack.entry.sha256,version:this.pack.entry.version,message:unknown?'Некоторые файлы отличаются. Завершите обновление игры и сохраните отчёт.':pending?'Предыдущая установка прервана.':stockCacheVariants?'Найден известный вариант кэша PGR. Можно установить перевод; исходный файл будет сохранён в резервной копии.':installed===this.plan.files.length&&originals!==this.plan.files.length?'Перевод найден; для удаления нужны прежние резервные копии.':''}
  }
  cacheOriginal(f,r){if(!r.exists)return {exists:false};const dest=under(this.tx.home,'originals/'+r.sha256+'.uab');if(fs.existsSync(dest))expect(dest,r);else copyNew(r.sourceFile,dest,r);return {exists:true,bytes:r.bytes,sha256:r.sha256}}
  async prepare(action){
    requireThat(['install','restore'].includes(action),'Неверное действие PGR.');if(this.state?.contextId===this.plan.contextId&&this.state.paths)requireThat(this.state.paths.every(p=>this.plan.files.some(f=>f.path===p)),'Новый пакет не покрывает прежний перевод PGR.');
    const legacy=pgrLegacyOriginals(this.root,this.store,this.plan,this.previous.map(p=>p.plan)),originals={},watch=[],ops=[]
    for(let i=0;i<this.plan.files.length;i++){
      const f=this.plan.files[i],file=under(this.root,f.path),before=fingerprint(file);if(!this.accepts(f,before)){const error=Error('Неизвестная версия ресурса PGR. Установка остановлена.');error.diagnostics={gameId:'pgr',problemFiles:[f.path],problemDetails:[{path:f.path,actual:before,expectedSource:{...source(f),sha1:f.sourceSha1},expectedTranslation:target(f)}]};throw error;}if(i%64===0)this.progress('Подготавливаю PGR: '+i+' / '+this.plan.files.length)
      let original=this.original(f)||legacy.get(f.path)
      if(!original&&recognizedStockCache(this.plan,f,before))original=canonicalStockCache(this.plan,f,before)
      if(!original){if(equal(before,source(f)))original={...before,sourceFile:file};else if(!before.exists&&f.allowAbsent)original={exists:false}}
      if(original)originals[f.path]=this.cacheOriginal(f,original)
      if(action==='restore')requireThat(original,'Не найдены проверенные оригинальные файлы для удаления перевода. Сохранённые копии не изменены.')
      const after=action==='install'?target(f):original.exists?{exists:true,bytes:original.bytes,sha256:original.sha256}:{exists:false};watch.push({path:f.path,before,after})
      if(!equal(before,after))ops.push({kind:'file',path:f.path,before,after,afterFile:after.exists?action==='install'?under(this.pack.root,f.stored):under(this.tx.home,'originals/'+after.sha256+'.uab'):null,order:0})
    }
    const afterState={format:'skadi-pgr-state-v1',gameId:'pgr',root:this.root,contextId:this.plan.contextId,reference:this.pack.ref,paths:this.plan.files.map(f=>f.path),originals,installed:action==='install'}
    return {action,contextId:this.plan.contextId,reference:this.pack.ref,previousReference:this.state?.reference||null,watch,ops,beforeState:this.state,afterState}
  }
  validateJournal(j){
    requireThat(j.contextId===this.plan.contextId&&['install','restore'].includes(j.action),'Журнал относится к другой версии PGR.');const paths=new Map(this.plan.files.map(f=>[f.path,f]));requireThat(j.watch.length===paths.size,'Неполный журнал PGR.')
    for(const w of j.watch){const f=paths.get(w.path);requireThat(f&&this.accepts(f,w.before)&&(j.action==='install'?equal(w.after,target(f)):equal(w.after,source(f))||(!w.after.exists&&f.allowAbsent)),'Журнал PGR не соответствует подписанному пакету.');paths.delete(w.path)}
    const unique=new Set();for(const op of j.ops){requireThat(op.kind==='file'&&!unique.has(op.path)&&j.watch.some(w=>w.path===op.path&&equal(w.before,op.before)&&equal(w.after,op.after)),'Недопустимая операция в журнале PGR.');unique.add(op.path)}
    requireThat(j.ops.length===j.watch.filter(w=>!equal(w.before,w.after)).length,'Неполный набор изменений PGR.')
  }
}
