import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {under,regular,hashBytes,requireThat} from './safe.mjs';
import crypto from 'node:crypto';

// One independently verified historical stock encoding. Never accept arbitrary cache files.
const CONTEXT='580591aeff97ee0a4594854c07f20057c5060bc0e5d94845c678416e959fe3e1';
const RESOURCE='PGR_Data/StreamingAssets/document/matrix/ca4588beda741bc7e48caafdc332b8d7000d4fb1.uab';
const SIZE=164343;
const OLD='b3b03e2d5d00f908030711aa61baa5d774f5b2405d9fd1eebbf08ca01def516b';
const CURRENT='d95a56a587b4bf7dc5385f42a35d6cb14d6a6f2dd89992c270e248c65422d17c';
const INDEX_SHA1='96cd981c56e30fe8198d4c2d49bce289e8265b9f';
export function recognizedStockCache(plan,file,actual){
 return plan.gameId==='pgr'&&plan.contextId===CONTEXT&&file.path===RESOURCE&&file.allowAbsent===true&&file.sourceBytes===SIZE&&file.sourceSha256===CURRENT&&file.sourceSha1===INDEX_SHA1&&actual.exists===true&&actual.bytes===SIZE&&actual.sha256===OLD;
}
export function canonicalStockCache(plan,file,actual){
 requireThat(recognizedStockCache(plan,file,actual),'Неизвестная версия ресурса PGR. Установка остановлена.');
 const sourceFile=under(path.dirname(fileURLToPath(import.meta.url)),'pgr-clean/'+CURRENT+'.uab');
 requireThat(regular(sourceFile).size===SIZE,'Проверенный исходный ресурс PGR повреждён.');
 const bytes=fs.readFileSync(sourceFile);requireThat(bytes.length===SIZE&&hashBytes(bytes)===CURRENT&&crypto.createHash('sha1').update(bytes).digest('hex')===INDEX_SHA1,'Проверенный исходный ресурс PGR повреждён.');
 return {exists:true,bytes:SIZE,sha256:CURRENT,sourceFile};
}
