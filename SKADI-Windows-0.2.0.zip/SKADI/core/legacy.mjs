import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {under,readJson,regular,hashFile,hashBytes,requireThat,readRange} from './safe.mjs'

export function pgrLegacyOriginals(root,store,plan,previous=[]){
  if(previous.length){
    const combined=pgrLegacyOriginals(root,store,plan),current=new Map(plan.files.map(f=>[f.path,f]));
    for(const old of previous){const adopted=pgrLegacyOriginals(root,store,old);for(const f of old.files){const now=current.get(f.path);if(now&&now.sourceSha256===f.sourceSha256&&now.sourceBytes===f.sourceBytes&&adopted.has(f.path)&&!combined.has(f.path))combined.set(f.path,adopted.get(f.path));}}
    return combined;
  }
  const base=path.join(path.dirname(store),'PGR_RU_PATCH'),key=crypto.createHash('sha1').update(path.resolve(root).replace(/[\\/]+$/,'').toLowerCase()).digest('hex'),state=path.join(base,key,'install_state.tsv');if(!fs.existsSync(state))return new Map()
  regular(state);requireThat(fs.statSync(state).size<8*1024*1024,'Старый журнал PGR слишком большой.');const lines=fs.readFileSync(state,'utf8').replace(/^\uFEFF/,'').split(/\r?\n/);requireThat(lines[0]==='#PGR_RU_PATCH_STATE_V1','Неизвестный журнал PGR.');let files=false,game='',backup='';const rows=new Map()
  for(const line of lines.slice(1)){if(!line)continue;if(line==='Files'){files=true;continue}if(!files){const i=line.indexOf('=');if(i<0)continue;const k=line.slice(0,i),v=line.slice(i+1);if(k==='GameRoot')game=v;if(k==='BackupRoot')backup=v;}else{const [name,flag,...rest]=line.split('\t'),rel=name.replaceAll('\\','/');requireThat(!rest.length&&!rows.has(rel)&&['0','1'].includes(flag),'Повреждён старый журнал PGR.');rows.set(rel,flag==='1')}}
  requireThat(path.resolve(game).toLowerCase()===path.resolve(root).toLowerCase(),'Старый журнал PGR относится к другой папке.');const parent=path.resolve(base,'Backups'),full=path.resolve(backup);requireThat(full.toLowerCase().startsWith(parent.toLowerCase()+path.sep),'Неизвестная папка старых копий PGR.');const map=new Map();let allMatched=rows.size===plan.files.length
  for(const f of plan.files){if(!rows.has(f.path)){allMatched=false;continue}if(rows.get(f.path)){const file=under(full,f.path);if(fs.existsSync(file)&&regular(file).size===f.sourceBytes&&hashFile(file)===f.sourceSha256)map.set(f.path,{exists:true,bytes:f.sourceBytes,sha256:f.sourceSha256,sourceFile:file});else allMatched=false;}}
  if(allMatched)for(const f of plan.files)if(rows.get(f.path)===false&&f.allowAbsent)map.set(f.path,{exists:false});return map
}

export function cznLegacyOriginals(root,pack){
  const plan=pack.czn,base='.czn_ru_ssra_'+plan.sourceManifestSha256.slice(0,12)+'_backup',file=under(root,base+'/state.json');if(!fs.existsSync(file))return null
  const state=readJson(file);requireThat(state.format==='czn-ssra-rollback-state-v1'&&state.planSha256===pack.plan.legacyPlanSha256&&state.sourceManifestSha256===plan.sourceManifestSha256&&Array.isArray(state.backups),'Старый журнал CZN не соответствует этому пакету.');
  const manifest=under(root,base+'/manifest.original.ssra');requireThat(hashFile(manifest)===plan.sourceManifestSha256,'Старый оригинальный манифест CZN повреждён.');const ranges=[]
  for(let ci=0;ci<plan.chunks.length;ci++)for(let pi=0;pi<plan.chunks[ci].patches.length;pi++){
    const c=plan.chunks[ci],p=c.patches[pi],name=base+'/blocks/'+String(ci).padStart(2,'0')+'-'+String(pi).padStart(2,'0')+'.bin';const found=state.backups.filter(x=>x.chunkIndex===ci&&x.patchIndex===pi);requireThat(found.length===1,'Старый журнал CZN неполный.');const row=found[0];requireThat(row.file===name&&row.bytes===p.targetBytes&&/^[a-f0-9]{64}$/.test(row.sha256),'Неверный старый блок CZN.');const bytes=fs.readFileSync(under(root,name));requireThat(bytes.length===row.bytes&&hashBytes(bytes)===row.sha256,'Старый блок CZN повреждён.');ranges.push({path:'chunks/'+c.name,sourceSha256:c.sourceSha256,offset:p.fileOffset,bytes,sha256:row.sha256})
  }
  requireThat(ranges.length===state.backups.length,'Лишние блоки в старом журнале CZN.');
  const etag=under(root,base+'/manifest.original.etag');let sourceEtag=null;if(state.sourceEtagSha256){requireThat(fs.existsSync(etag)&&hashFile(etag)===state.sourceEtagSha256,'Старый кэш манифеста CZN повреждён.');sourceEtag=fs.readFileSync(etag)}
  return {ranges,sourceManifest:fs.readFileSync(manifest),sourceEtag,phase:state.phase}
}
