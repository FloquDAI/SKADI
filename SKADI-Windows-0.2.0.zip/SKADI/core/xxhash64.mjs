// XXH64, seed 0. Public integrity helper for SSRA manifest cache metadata.
const MASK = (1n << 64n) - 1n
const P1 = 0x9e3779b185ebca87n
const P2 = 0xc2b2ae3d27d4eb4fn
const P3 = 0x165667b19e3779f9n
const P4 = 0x85ebca77c2b2ae63n
const P5 = 0x27d4eb2f165667c5n
const rotate = (value, bits) => ((value << BigInt(bits)) | (value >> BigInt(64 - bits))) & MASK
const round = (acc, input) => (rotate((acc + input * P2) & MASK, 31) * P1) & MASK
const merge = (acc, value) => ((acc ^ round(0n, value)) * P1 + P4) & MASK

export function xxhash64(data, seed = 0n) {
  let cursor = 0
  let hash
  if (data.length >= 32) {
    let a = (seed + P1 + P2) & MASK
    let b = (seed + P2) & MASK
    let c = seed & MASK
    let d = (seed - P1) & MASK
    while (cursor <= data.length - 32) {
      a = round(a, data.readBigUInt64LE(cursor)); cursor += 8
      b = round(b, data.readBigUInt64LE(cursor)); cursor += 8
      c = round(c, data.readBigUInt64LE(cursor)); cursor += 8
      d = round(d, data.readBigUInt64LE(cursor)); cursor += 8
    }
    hash = (rotate(a, 1) + rotate(b, 7) + rotate(c, 12) + rotate(d, 18)) & MASK
    hash = merge(merge(merge(merge(hash, a), b), c), d)
  } else hash = (seed + P5) & MASK
  hash = (hash + BigInt(data.length)) & MASK
  while (cursor <= data.length - 8) {
    hash ^= round(0n, data.readBigUInt64LE(cursor)); cursor += 8
    hash = (rotate(hash, 27) * P1 + P4) & MASK
  }
  if (cursor <= data.length - 4) {
    hash ^= BigInt(data.readUInt32LE(cursor)) * P1; cursor += 4
    hash = (rotate(hash & MASK, 23) * P2 + P3) & MASK
  }
  while (cursor < data.length) {
    hash ^= BigInt(data[cursor++]) * P5
    hash = (rotate(hash & MASK, 11) * P1) & MASK
  }
  hash ^= hash >> 33n
  hash = (hash * P2) & MASK
  hash ^= hash >> 29n
  hash = (hash * P3) & MASK
  hash ^= hash >> 32n
  return hash & MASK
}
