import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
export const requireThat=(v,m)=>{if(!v)throw new Error(m)}
export const hashBytes=b=>crypto.createHash('sha256').update(b).digest('hex')
export const isHash=s=>typeof s==='string'&&/^[a-f0-9]{64}$/.test(s)
export function relative(value){
  requireThat(typeof value==='string'&&value.length>0&&value.length<240&&!value.includes('\\')&&!value.startsWith('/')&&!value.includes(':')&&!/[\x00-\x1f]/.test(value),'Недопустимый путь данных.')
  requireThat(value.split('/').every(p=>p&&p!=='.'&&p!=='..'&&!/[. ]$/.test(p)&&!/[<>"|?*]/.test(p)&&!/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p)),'Недопустимый путь данных.');return value
}
export function under(root,value){
  relative(value);const base=path.resolve(root),full=path.resolve(base,...value.split('/'))
  requireThat(full.toLowerCase().startsWith(base.toLowerCase()+path.sep),'Путь вышел за разрешённую папку.')
  let current=base
  for(const piece of value.split('/')){current=path.join(current,piece);if(fs.existsSync(current))requireThat(!fs.lstatSync(current).isSymbolicLink(),'Ссылки в путях установки не поддерживаются.')}
  return full
}
export function regular(file){const s=fs.lstatSync(file);requireThat(s.isFile()&&!s.isSymbolicLink(),'Файл отсутствует или заменён ссылкой.');return s}
export function hashFile(file,algorithm='sha256'){
  regular(file);const hash=crypto.createHash(algorithm),fd=fs.openSync(file,'r'),block=Buffer.alloc(1024*1024)
  try{for(;;){const n=fs.readSync(fd,block,0,block.length,null);if(!n)break;hash.update(block.subarray(0,n))}}finally{fs.closeSync(fd)}return hash.digest('hex')
}
export function fingerprint(file){if(!fs.existsSync(file))return {exists:false};const s=regular(file),sha256=hashFile(file);requireThat(fs.statSync(file).size===s.size,'Файл менялся во время проверки.');return {exists:true,bytes:s.size,sha256}}
export const equal=(a,b)=>a?.exists===b?.exists&&(!a.exists||(a.bytes===b.bytes&&a.sha256===b.sha256))
export function expect(file,fp){requireThat(equal(fingerprint(file),fp),'Файл изменился или повреждён: '+path.basename(file))}
export function syncDirectory(dir){if(process.platform==='win32')return;const fd=fs.openSync(dir,'r');try{fs.fsyncSync(fd)}finally{fs.closeSync(fd)}}
export function mkdir(dir){fs.mkdirSync(dir,{recursive:true});requireThat(!fs.lstatSync(dir).isSymbolicLink(),'Недопустимая ссылка.');return dir}
export function atomic(file,bytes){
  mkdir(path.dirname(file));if(fs.existsSync(file))regular(file);const temp=file+'.skadi-'+crypto.randomUUID()+'.tmp',fd=fs.openSync(temp,'wx')
  try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd)}finally{fs.closeSync(fd)}
  fs.renameSync(temp,file);syncDirectory(path.dirname(file))
}
export const writeJson=(file,value)=>atomic(file,Buffer.from(JSON.stringify(value,null,2)+'\n'))
export function readJson(file,max=8*1024*1024){const s=regular(file);requireThat(s.size<=max,'Слишком большой служебный файл.');return JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''))}
export function copyNew(source,target,fp){
  regular(source);mkdir(path.dirname(target));requireThat(!fs.existsSync(target),'Временный файл уже существует.');const input=fs.openSync(source,'r'),output=fs.openSync(target,'wx'),block=Buffer.alloc(1024*1024),hash=crypto.createHash('sha256');let total=0
  try{for(;;){const n=fs.readSync(input,block,0,block.length,null);if(!n)break;requireThat(total+n<=fp.bytes,'Копия содержит лишние данные.');let done=0;while(done<n)done+=fs.writeSync(output,block,done,n-done,null);hash.update(block.subarray(0,n));total+=n}fs.fsyncSync(output)}finally{fs.closeSync(input);fs.closeSync(output)}
  requireThat(total===fp.bytes&&hash.digest('hex')===fp.sha256,'Копия не прошла проверку.');syncDirectory(path.dirname(target))
}
export function readRange(file,offset,length){
  requireThat(Number.isSafeInteger(offset)&&offset>=0&&Number.isSafeInteger(length)&&length>0&&length<=128*1024*1024,'Недопустимый диапазон.');regular(file);const fd=fs.openSync(file,'r'),out=Buffer.alloc(length)
  try{let done=0;while(done<length){const n=fs.readSync(fd,out,done,length-done,offset+done);requireThat(n>0,'Неполное чтение ресурса.');done+=n}}finally{fs.closeSync(fd)}return out
}
export function writeRange(file,offset,bytes){
  requireThat(Number.isSafeInteger(offset)&&offset>=0&&Buffer.isBuffer(bytes)&&bytes.length>0&&bytes.length<=128*1024*1024,'Недопустимая запись.');regular(file);const fd=fs.openSync(file,'r+')
  try{let done=0;while(done<bytes.length){const n=fs.writeSync(fd,bytes,done,Math.min(65536,bytes.length-done),offset+done);requireThat(n>0,'Не удалось записать ресурс.');done+=n}fs.fsyncSync(fd)}finally{fs.closeSync(fd)}
}
export function virtualHash(file,overlays){
  const size=regular(file).size,fd=fs.openSync(file,'r'),hash=crypto.createHash('sha256'),block=Buffer.alloc(4*1024*1024)
  try{for(let offset=0;offset<size;){const n=fs.readSync(fd,block,0,Math.min(block.length,size-offset),offset);requireThat(n>0,'Неполное чтение архива.');const buffer=block.subarray(0,n)
    for(const r of overlays){const left=Math.max(offset,r.offset),right=Math.min(offset+n,r.offset+r.bytes.length);if(left<right)r.bytes.copy(buffer,left-offset,left-r.offset,right-r.offset)}hash.update(buffer);offset+=n}}
  finally{fs.closeSync(fd)}return hash.digest('hex')
}
export function rangesUnion(rows){
  const result=[];for(const row of [...rows].sort((a,b)=>a.offset-b.offset)){requireThat(Number.isSafeInteger(row.offset)&&row.offset>=0&&Number.isSafeInteger(row.length)&&row.length>0,'Неверный диапазон.');const end=row.offset+row.length,last=result.at(-1);if(last&&row.offset<=last.offset+last.length)last.length=Math.max(last.offset+last.length,end)-last.offset;else result.push({offset:row.offset,length:row.length})}return result
}
export function knownTransition(current,before,after){if(current.length!==before.length||before.length!==after.length)return false;for(let i=0;i<current.length;i++)if(current[i]!==before[i]&&current[i]!==after[i])return false;return true}
