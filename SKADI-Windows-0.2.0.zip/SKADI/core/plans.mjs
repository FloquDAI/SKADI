import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import {requireThat,isHash,under,readJson,hashBytes,hashFile,regular} from './safe.mjs'
const indexNames=['PGR_Data/StreamingAssets/document/launch/index','PGR_Data/StreamingAssets/document/matrix/index','PGR_Data/StreamingAssets/resource/launch/index','PGR_Data/StreamingAssets/resource/matrix/index']
export function pgrContext(indexes){return hashBytes(Buffer.from('SKADI-PGR-PC-V1\n'+[...indexes].sort((a,b)=>a.relative_path.localeCompare(b.relative_path,'en')).map(x=>x.relative_path+'\t'+x.sha256+'\n').join('')))}
export function allowedGamePath(gameId,value){return gameId==='pgr'?/^PGR_Data\/StreamingAssets\/(document|resource)\/(matrix|launch)\/[0-9a-f]{40}\.uab$/.test(value):value==='manifest.ssra'||value==='manifest.ssra.etag'||/^chunks\/(?:lang_en_b\d{2}_0|base_b\d{2}_0|base_large_[a-z0-9_]+)\.ssrc$/.test(value)}
function fileSet(root){const result=[];function walk(dir,prefix=''){for(const name of fs.readdirSync(dir)){const rel=prefix+name,file=under(root,rel),s=fs.lstatSync(file);requireThat(!s.isSymbolicLink(),'Ссылка в пакете обновления.');if(s.isDirectory())walk(file,rel+'/');else{requireThat(s.isFile(),'Неизвестный объект в пакете.');result.push(rel)}}}walk(root);return result}
export function validatePackage(pack,progress=()=>{}){
  const p=pack.plan,expected=new Set(['plan.json']);requireThat(p.platform==='windows'&&isHash(p.contextId),'Неверная платформа пакета.')
  if(p.gameId==='pgr'){
    requireThat(p.format==='skadi-pgr-files-v1'&&Array.isArray(p.indexes)&&p.indexes.length===4&&pgrContext(p.indexes)===p.contextId,'Неверная версия ресурсов PGR.');const indexes=new Set(indexNames)
    for(const x of p.indexes)requireThat(indexes.delete(x.relative_path)&&isHash(x.sha256),'Неверный исходный индекс PGR.')
    requireThat(Array.isArray(p.files)&&p.files.length>0&&p.files.length<=16000,'Неверный список файлов PGR.');const paths=new Set();let total=0
    for(const f of p.files){
      requireThat(allowedGamePath('pgr',f.path)&&!paths.has(f.path.toLowerCase())&&isHash(f.sha256)&&isHash(f.sourceSha256)&&/^[a-f0-9]{40}$/.test(f.sourceSha1),'Неверный адрес ресурса PGR.');paths.add(f.path.toLowerCase())
      requireThat(f.stored==='stored/'+f.sha256+'.uab'&&Number.isSafeInteger(f.bytes)&&f.bytes>0&&f.bytes<=512*1024*1024&&Number.isSafeInteger(f.sourceBytes)&&f.sourceBytes>0&&f.sourceBytes<=512*1024*1024&&f.allowAbsent===f.path.includes('/document/'),'Неверное описание ресурса PGR.')
      requireThat(Array.isArray(f.knownPrevious)&&f.knownPrevious.length<=16&&f.knownPrevious.every(x=>isHash(x.sha256)&&Number.isSafeInteger(x.bytes)&&x.bytes>0),'Неверные предыдущие версии PGR.');total+=f.bytes;requireThat(total<=4*1024**3,'Пакет PGR слишком большой.')
      if(!expected.has(f.stored)){expected.add(f.stored);if(!pack.metadataOnly){const file=under(pack.root,f.stored);requireThat(regular(file).size===f.bytes&&hashFile(file)===f.sha256,'Повреждён ресурс PGR.');if(expected.size%64===0)progress('Проверяю пакет PGR: '+expected.size)}}
    }
    for(const name of ['FONT_LICENSE_BarlowCondensed.txt','FONT_COPYRIGHT_BarlowCondensed.txt'])if(fs.existsSync(under(pack.root,name))){requireThat(regular(under(pack.root,name)).size<16384,'Слишком большой служебный файл.');expected.add(name)}
  }else{
    requireThat(p.gameId==='czn'&&p.format==='skadi-czn-ranges-v1'&&p.contextId===p.sourceManifestSha256&&p.originalPlan==='czn/install-plan.json'&&p.originalMetadata==='czn/manifest.json'&&p.targetManifest==='czn/manifest.target.ssra','Неверный формат CZN.')
    const plan=readJson(under(pack.root,p.originalPlan)),meta=readJson(under(pack.root,p.originalMetadata));requireThat(hashFile(under(pack.root,p.originalPlan))===p.legacyPlanSha256&&plan.format==='czn-ssra-safe-install-plan-v1'&&meta.format==='czn-ssra-keyless-payload-v1'&&plan.sourceManifestSha256===p.sourceManifestSha256&&plan.targetManifestSha256===p.targetManifestSha256&&meta.packageVersion===plan.packageVersion,'Исходный план CZN повреждён.')
    requireThat(hashFile(under(pack.root,p.targetManifest))===p.targetManifestSha256,'Манифест CZN повреждён.');expected.add(p.originalPlan);expected.add(p.originalMetadata);expected.add(p.targetManifest)
    requireThat(Array.isArray(plan.chunks)&&plan.chunks.length>0&&plan.chunks.length<=256&&Array.isArray(meta.resources)&&meta.resources.length===plan.resourceCount,'Неверный список ресурсов CZN.');const names=new Set(),resources=new Map(meta.resources.map(r=>[r.name,r]));requireThat(resources.size===meta.resources.length,'Повторяющиеся ресурсы CZN.');let found=0
    for(const c of plan.chunks){
      requireThat(allowedGamePath('czn','chunks/'+c.name)&&!names.has(c.name)&&Number.isSafeInteger(c.diskBytes)&&c.diskBytes>16&&c.diskBytes<=8*1024**3&&c.bodyBytes===c.diskBytes-16&&isHash(c.sourceSha256)&&isHash(c.targetSha256)&&/^[0-9a-f]{16}$/.test(c.sourceXxh64)&&/^[0-9a-f]{16}$/.test(c.targetXxh64)&&Array.isArray(c.patches)&&c.patches.length>0,'Некорректный архив CZN.');names.add(c.name);let lastEnd=0
      for(const x of [...c.patches].sort((a,b)=>a.fileOffset-b.fileOffset)){
        requireThat(Number.isSafeInteger(x.fileOffset)&&x.fileOffset>=lastEnd&&Number.isSafeInteger(x.sourceBytes)&&x.sourceBytes>0&&x.sourceBytes<=128*1024*1024&&Number.isSafeInteger(x.targetBytes)&&x.targetBytes>0&&x.targetBytes<=x.sourceBytes&&x.fileOffset+x.sourceBytes<=c.bodyBytes&&/^stored\/\d{2}\.zst$/.test(x.targetStoredFile)&&isHash(x.sourceStoredSha256)&&isHash(x.targetStoredSha256),'Неверный блок CZN.');lastEnd=x.fileOffset+x.sourceBytes
        const m=resources.get(x.name);requireThat(m&&m.targetStoredSha256===x.targetStoredSha256&&m.targetStoredBytes===x.targetBytes,'Ресурс CZN отсутствует в плане.');resources.delete(x.name);found++
        const rel='czn/'+x.targetStoredFile;requireThat(!expected.has(rel),'Повторяющийся блок CZN.');expected.add(rel)
        if(!pack.metadataOnly){const file=under(pack.root,rel),bytes=fs.readFileSync(file);requireThat(bytes.length===x.targetBytes&&hashBytes(bytes)===x.targetStoredSha256,'Повреждён блок перевода CZN.');const decoded=zlib.zstdDecompressSync(bytes,{maxOutputLength:128*1024*1024});requireThat(decoded.length===m.targetPlainBytes&&hashBytes(decoded)===m.targetPlainSha256,'Блок CZN не прошёл распаковку.');progress('Проверяю пакет CZN: '+found)}
      }
    }
    requireThat(resources.size===0,'Неполное покрытие CZN.');pack.czn=plan;pack.cznMetadata=meta
  }
  if(pack.metadataOnly)for(const f of [...expected])if(f.startsWith('stored/')||f.startsWith('czn/stored/'))expected.delete(f)
  const actual=fileSet(pack.root);requireThat(actual.length===expected.size&&actual.every(f=>expected.has(f)),'В пакете обнаружены лишние файлы.');return pack
}
