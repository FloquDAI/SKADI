import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {under,hashFile,requireThat,regular} from './safe.mjs'

export function gameGuard(root,pack,previous=[],allowRunning=false){
  let last=0,identity=null;
  return async function(force=false){
    if(!force&&Date.now()-last<500)return;last=Date.now();
    if(process.platform==='win32'&&!allowRunning){
      const tasks=execFileSync('tasklist.exe',['/FO','CSV','/NH'],{encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024,timeout:15000});const running=pack.plan.gameId==='pgr'?/(^|\r?\n)"PGR\.exe"/i.test(tasks):/(^|\r?\n)"(?:ChaosZeroNightmare|ucldr_ChaosZeroNightmare[^"\r\n]*)\.exe"/i.test(tasks);requireThat(!running,'Игра запущена. Закройте её и повторите операцию.');
    }
    if(pack.plan.gameId==='pgr'){
      requireThat(fs.existsSync(under(root,'PGR.exe')),'Выбрана другая папка игры.');for(const i of pack.plan.indexes)requireThat(hashFile(under(root,i.relative_path))===i.sha256,'Игра обновилась. Нужен совместимый пакет перевода.');
      const file=under(root,'PGR.exe'),s=regular(file),now={bytes:s.size,modified:s.mtimeMs};if(identity)requireThat(identity.bytes===now.bytes&&identity.modified===now.modified,'Игра менялась во время установки.');else identity=now;
    }else{
      requireThat(path.basename(root).toLowerCase()==='gameres','Выберите папку данных CZN.');const current=hashFile(under(root,'manifest.ssra'));const allowed=[pack,...previous].filter(p=>p.plan.contextId===pack.plan.contextId).flatMap(p=>[p.plan.sourceManifestSha256,p.plan.targetManifestSha256]);requireThat(allowed.includes(current),'Манифест игры обновился. Нужен совместимый пакет перевода.');
    }
  }
}
