import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {under,mkdir,readJson,writeJson,hashBytes,hashFile,fingerprint,equal,expect,copyNew,atomic,readRange,writeRange,virtualHash,knownTransition,requireThat,syncDirectory} from './safe.mjs'
import {allowedGamePath} from './plans.mjs'

/** Whole-file PGR and bounded-range CZN transactions share durable actual-preimage journals. */
export class Transaction {
  constructor({root,store,gameId,guard,progress=()=>{},fault=()=>{}}){this.root=path.resolve(root);this.store=store;this.gameId=gameId;this.guard=guard;this.progress=progress;this.fault=fault;this.home=under(store,'games/'+gameId+'/'+hashBytes(Buffer.from(this.root.replaceAll('\\','/').replace(/\/$/,'').toLowerCase())));mkdir(this.home)}
  pending(){const file=under(this.home,'active.json');if(!fs.existsSync(file))return null;const id=readJson(file).id;requireThat(/^[0-9a-f-]{36}$/.test(id),'Повреждён журнал установки.');const journal=readJson(under(this.home,'transactions/'+id+'/journal.json'),32*1024*1024);requireThat(journal.id===id&&journal.gameId===this.gameId&&path.resolve(journal.root)===this.root,'Журнал относится к другой игре.');return journal}
  save(j){writeJson(under(this.home,'transactions/'+j.id+'/journal.json'),j)}
  clear(){const file=under(this.home,'active.json');if(fs.existsSync(file)){fs.unlinkSync(file);syncDirectory(this.home)}}
  blob(j,name){requireThat(/^(before|after)\/\d{1,5}\.bin$/.test(name),'Неверный файл журнала.');return under(this.home,'transactions/'+j.id+'/'+name)}
  sibling(j,op,suffix='stage'){requireThat(allowedGamePath(this.gameId,op.path),'Неверный путь установки.');const target=under(this.root,op.path);return path.join(path.dirname(target),'.skadi-'+j.id+'-'+path.basename(target)+'.'+suffix)}
  cleanup(j){for(const op of j.ops){if(op.kind!=='file'||!op.after.exists)continue;const file=this.sibling(j,op);if(fs.existsSync(file)&&equal(fingerprint(file),op.after)){fs.unlinkSync(file);syncDirectory(path.dirname(file))}}}
  async run(prepared){
    requireThat(!this.pending(),'Предыдущая установка прервана. Сначала восстановите её.');await this.guard(true);
    const space=new Map();const reserve=64*1024*1024;
    for(const [base,bytes] of [[this.home,prepared.ops.reduce((n,o)=>n+(o.before.exists?o.before.bytes:0)+(o.after.exists?o.after.bytes:0),0)],[this.root,prepared.ops.filter(o=>o.kind==='file').reduce((n,o)=>n+(o.after.exists?o.after.bytes:0),0)]]){
      const stat=fs.statfsSync(base),key=process.platform==='win32'?path.parse(base).root:String(fs.statSync(base).dev);const need=(space.get(key)?.need||0)+bytes;space.set(key,{need,available:stat.bavail*stat.bsize});
    }
    for(const {need,available} of space.values())requireThat(available>need+reserve,'Недостаточно места для установки и резервных копий. Освободите место и повторите.');
    const id=crypto.randomUUID(),j={format:'skadi-transaction-v1',id,gameId:this.gameId,root:this.root,contextId:prepared.contextId,action:prepared.action,reference:prepared.reference,previousReference:prepared.previousReference||null,phase:'preparing',watch:prepared.watch,ops:[],beforeState:prepared.beforeState||null,afterState:prepared.afterState||null,createdAt:new Date().toISOString()};
    const folder=under(this.home,'transactions/'+id);mkdir(folder);
    for(let i=0;i<prepared.ops.length;i++){
      const p=prepared.ops[i];requireThat(allowedGamePath(this.gameId,p.path)&&['file','range'].includes(p.kind),'Недопустимая операция игры.');
      const op={kind:p.kind,path:p.path,before:p.before,after:p.after,order:p.order||0,beforeBlob:'before/'+i+'.bin',afterBlob:'after/'+i+'.bin'};
      if(p.kind==='range'){op.offset=p.offset;op.length=p.before.bytes;requireThat(op.length===p.after.bytes&&op.length>0&&op.length<=128*1024*1024,'Неверный диапазон транзакции.');}
      j.ops.push(op);
    }
    this.save(j);writeJson(under(this.home,'active.json'),{id});
    try{
      j.phase='backing_up';this.save(j);
      for(let i=0;i<j.ops.length;i++){
        const op=j.ops[i],source=under(this.root,op.path);this.progress('Сохраняю резервные копии: '+(i+1)+' / '+j.ops.length);
        if(op.kind==='file'){expect(source,op.before);if(op.before.exists)copyNew(source,this.blob(j,op.beforeBlob),op.before)}
        else{const bytes=readRange(source,op.offset,op.length);requireThat(hashBytes(bytes)===op.before.sha256,'Ресурс менялся во время резервного копирования.');atomic(this.blob(j,op.beforeBlob),bytes)}
        await this.fault('backup',i,j);
      }
      j.phase='staging';this.save(j);
      for(let i=0;i<j.ops.length;i++){
        const op=j.ops[i],p=prepared.ops[i];this.progress('Подготавливаю установку: '+(i+1)+' / '+j.ops.length);
        if(op.after.exists){
          if(p.afterFile)copyNew(p.afterFile,this.blob(j,op.afterBlob),op.after);
          else{requireThat(Buffer.isBuffer(p.afterBytes)&&p.afterBytes.length===op.after.bytes&&hashBytes(p.afterBytes)===op.after.sha256,'Неверные подготовленные данные.');atomic(this.blob(j,op.afterBlob),p.afterBytes)}
          if(op.kind==='file'){const stage=this.sibling(j,op);copyNew(this.blob(j,op.afterBlob),stage,op.after);}
        }
        await this.fault('stage',i,j);
      }
      await this.guard(true);this.validateBefore(j);j.phase='committing';this.save(j);await this.fault('commit_gate',-1,j);
      for(const i of j.ops.map((_,i)=>i).sort((a,b)=>j.ops[a].order-j.ops[b].order)){
        const op=j.ops[i],target=under(this.root,op.path);await this.guard();this.progress('Устанавливаю: '+(i+1)+' / '+j.ops.length);
        if(op.kind==='file'){
          expect(target,op.before);
          if(op.after.exists){const stage=this.sibling(j,op);expect(stage,op.after);requireThat(path.dirname(stage)===path.dirname(target),'Временный файл должен находиться рядом с ресурсом.');fs.renameSync(stage,target);syncDirectory(path.dirname(target));}
          else if(op.before.exists){fs.unlinkSync(target);syncDirectory(path.dirname(target));}
          expect(target,op.after);
        }else{
          const current=readRange(target,op.offset,op.length);requireThat(hashBytes(current)===op.before.sha256,'Блок игры изменён другой программой.');const bytes=fs.readFileSync(this.blob(j,op.afterBlob));requireThat(hashBytes(bytes)===op.after.sha256,'Подготовленный блок повреждён.');writeRange(target,op.offset,bytes);requireThat(hashBytes(readRange(target,op.offset,op.length))===op.after.sha256,'Проверка записанного блока не прошла.');
        }
        await this.fault('committed',i,j);
      }
      await this.guard(true);for(const w of j.watch)expect(under(this.root,w.path),w.after);
      j.phase='complete';j.finishedAt=new Date().toISOString();this.save(j);if(j.afterState)writeJson(under(this.home,'state.json'),j.afterState);this.clear();return j;
    }catch(error){
      if(error.simulatedDeath)throw error;
      if(j.phase==='complete')throw error;
      if(j.phase==='committing'){
        try{await this.rollback(j);this.cleanup(j);j.phase='rolled_back';this.save(j);this.restoreState(j);this.clear();}
        catch(recovery){throw new Error('Установка прервана. Резервные копии сохранены; требуется восстановление. '+recovery.message,{cause:error})}
      }else{this.cleanup(j);j.phase='aborted_before_commit';this.save(j);this.clear();}
      throw error;
    }
  }
  validateBefore(j){
    for(const w of j.watch)expect(under(this.root,w.path),w.before);
    for(const op of j.ops){if(op.before.exists)expect(this.blob(j,op.beforeBlob),op.before);if(op.after.exists){expect(this.blob(j,op.afterBlob),op.after);if(op.kind==='file')expect(this.sibling(j,op),op.after)}}
  }
  restoreState(j){const file=under(this.home,'state.json');if(j.beforeState)writeJson(file,j.beforeState);else if(fs.existsSync(file))fs.unlinkSync(file)}
  async rollback(j){
    await this.guard(true);requireThat(j.format==='skadi-transaction-v1'&&j.ops.length<=32000&&j.watch.length<=16010,'Неизвестный журнал транзакции.');
    // Check every backup, transition and virtual whole file before any rollback write.
    for(const op of j.ops){
      requireThat(allowedGamePath(this.gameId,op.path),'Небезопасный путь журнала.');const target=under(this.root,op.path);
      if(op.before.exists)expect(this.blob(j,op.beforeBlob),op.before);if(op.after.exists)expect(this.blob(j,op.afterBlob),op.after);
      if(op.kind==='file')requireThat(equal(fingerprint(target),op.before)||equal(fingerprint(target),op.after),'Файл изменён извне; автоматический откат остановлен.');
      else{const current=readRange(target,op.offset,op.length),before=fs.readFileSync(this.blob(j,op.beforeBlob)),after=fs.readFileSync(this.blob(j,op.afterBlob));requireThat(knownTransition(current,before,after),'Неизвестные изменения блока; откат остановлен.');}
    }
    for(const w of j.watch){const ops=j.ops.filter(o=>o.kind==='range'&&o.path===w.path);if(ops.length){const overlays=ops.map(o=>({offset:o.offset,bytes:fs.readFileSync(this.blob(j,o.beforeBlob))}));requireThat(virtualHash(under(this.root,w.path),overlays)===w.before.sha256,'Архив изменился вне блоков перевода; откат остановлен.');}else if(!j.ops.some(o=>o.path===w.path))expect(under(this.root,w.path),w.before);}
    for(const op of [...j.ops].sort((a,b)=>a.order-b.order)){
      await this.guard();const target=under(this.root,op.path);this.progress('Восстанавливаю сохранённые файлы…');
      if(op.kind==='file'){
        if(equal(fingerprint(target),op.before))continue;
        if(op.before.exists){const temp=this.sibling(j,op,'restore-'+crypto.randomUUID());copyNew(this.blob(j,op.beforeBlob),temp,op.before);fs.renameSync(temp,target);syncDirectory(path.dirname(target));}
        else if(fs.existsSync(target)){expect(target,op.after);fs.unlinkSync(target);syncDirectory(path.dirname(target));}
      }else{const current=readRange(target,op.offset,op.length);if(hashBytes(current)!==op.before.sha256)writeRange(target,op.offset,fs.readFileSync(this.blob(j,op.beforeBlob)));}
    }
    for(const w of j.watch)expect(under(this.root,w.path),w.before);
  }
  async recover(validate){
    const j=this.pending();requireThat(j,'Прерванных установок нет.');await validate(j);await this.guard(true);
    if(j.phase==='committing'){await this.rollback(j);this.restoreState(j);j.phase='rolled_back';this.save(j)}
    else if(j.phase==='complete'){if(j.afterState)writeJson(under(this.home,'state.json'),j.afterState)}
    else requireThat(['preparing','backing_up','staging','rolled_back','aborted_before_commit'].includes(j.phase),'Неизвестное состояние установки.');
    this.cleanup(j);this.clear();return j;
  }
}
