import fs from 'node:fs'
import crypto from 'node:crypto'
import {isHash,hashBytes,requireThat,readJson,under,hashFile} from './safe.mjs'
const GAME_IDS=new Set(['pgr','czn'])
export function verifyCatalog(bytes,signature,key){
  requireThat(bytes.length>0&&bytes.length<=256*1024&&signature.length===384,'Некорректный каталог обновлений.')
  requireThat(crypto.verify('sha256',bytes,key,signature),'Подпись каталога обновлений не совпала.')
  const value=JSON.parse(bytes.toString('utf8'));requireThat(value.format==='skadi-signed-catalog-v1'&&Number.isSafeInteger(value.revision)&&value.revision>0&&Array.isArray(value.packages)&&value.packages.length>0&&value.packages.length<=256,'Неизвестный каталог SKADI.')
  const seen=new Set()
  for(const p of value.packages){
    requireThat(GAME_IDS.has(p.gameId)&&p.platform==='windows'&&isHash(p.contextId)&&isHash(p.sha256)&&isHash(p.planSha256)&&!seen.has(p.sha256),'Некорректная запись обновления.');seen.add(p.sha256)
    requireThat(Number.isSafeInteger(p.bytes)&&p.bytes>0&&p.bytes<=1024*1024*1024&&Number.isSafeInteger(p.sequence)&&p.sequence>0&&Number.isSafeInteger(p.minLauncherCode)&&p.minLauncherCode>0&&/^[A-Za-z0-9._-]{1,80}$/.test(p.version),'Некорректная версия обновления.')
    releaseUrl(p.url);releaseUrl(p.metadataUrl);requireThat(isHash(p.metadataSha256)&&Number.isSafeInteger(p.metadataBytes)&&p.metadataBytes>0&&p.metadataBytes<=16*1024*1024,'Неверные метаданные пакета.')
  }
  return {value,hash:hashBytes(bytes),byHash(hash){const p=value.packages.find(p=>p.sha256===hash);requireThat(p,'Пакет отсутствует в подписанном каталоге.');return p}}
}
export function releaseUrl(url){const u=new URL(url);requireThat(u.protocol==='https:'&&u.hostname==='github.com'&&!u.port&&!u.username&&!u.password&&!u.search&&!u.hash&&/^\/FloquDAI\/SKADI\/releases\/download\/[A-Za-z0-9._-]+\/[A-Za-z0-9._-]+$/.test(u.pathname),'Недопустимый адрес пакета SKADI.');return url}
export function cachedCatalog(store,hash,key){requireThat(isHash(hash),'Неверная ссылка на каталог.');const bytes=fs.readFileSync(under(store,'catalogs/'+hash+'.json'));requireThat(hashBytes(bytes)===hash,'Каталог в кэше повреждён.');return verifyCatalog(bytes,fs.readFileSync(under(store,'catalogs/'+hash+'.sig')),key)}
export function packageReference(store,ref,key,metadataOnly=false){const c=cachedCatalog(store,ref.catalogHash,key),entry=c.byHash(ref.packageHash),root=under(store,(metadataOnly?'metadata/':'packages/')+entry.sha256),planFile=under(root,'plan.json');requireThat(hashFile(planFile)===entry.planSha256,'План пакета повреждён.');const plan=readJson(planFile);requireThat(plan.gameId===entry.gameId&&plan.contextId===entry.contextId&&plan.version===entry.version&&plan.platform==='windows','Пакет не соответствует каталогу.');return {entry,root,plan,ref,metadataOnly}}
