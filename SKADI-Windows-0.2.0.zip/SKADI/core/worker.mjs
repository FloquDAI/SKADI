import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {under,readJson,hashBytes,hashFile,requireThat,isHash} from './safe.mjs'
import {cachedCatalog,packageReference} from './catalog.mjs'
import {validatePackage} from './plans.mjs'
import {gameGuard} from './guard.mjs'
import {Transaction} from './transaction.mjs'
import {PgrAdapter} from './pgr.mjs'
import {CznAdapter} from './czn.mjs'

const emit=value=>process.stdout.write(JSON.stringify(value)+'\n')
async function main(){
  requireThat(process.argv.length===4&&process.argv[2]==='--request','Неверный запуск рабочего процесса.');
  const requestFile=path.resolve(process.argv[3]),request=readJson(requestFile,65536),folder=path.dirname(requestFile);
  requireThat(request.format==='skadi-operation-request-v1'&&/^[a-f0-9-]{36}$/.test(request.id)&&['install','inspect','restore','recover'].includes(request.action)&&['czn','pgr'].includes(request.gameId),'Неверная операция SKADI.');
  requireThat(path.resolve(under(request.store,'operations/'+request.id+'/request.json'))===requestFile,'Неверный путь задания.');
  const readyFile=under(folder,'ready.json');for(let i=0;i<200&&!fs.existsSync(readyFile);i++)await new Promise(r=>setTimeout(r,25));
  const ready=readJson(readyFile,4096);requireThat(ready.id===request.id&&ready.requestHash===hashFile(requestFile)&&ready.parentPid===process.ppid,'Рабочий процесс не привязан к SKADI.');
  const root=path.resolve(request.root);requireThat(!root.startsWith('\\\\')&&path.isAbsolute(request.root),'Неверная папка игры.');
  for(let current=root;;current=path.dirname(current)){requireThat(!fs.lstatSync(current).isSymbolicLink(),'Ссылки в пути игры не поддерживаются.');if(path.dirname(current)===current)break;}
  const key=fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)),'release-public.pem'));
  let progressAt=0;const progress=text=>{if(Date.now()-progressAt>=200){emit({type:'progress',text});progressAt=Date.now();}},cache=new Map();
  function load(ref,metadata=true){requireThat(ref&&isHash(ref.catalogHash)&&isHash(ref.packageHash),'Неверная ссылка на пакет.');const id=ref.catalogHash+'/'+ref.packageHash+'/'+metadata;if(cache.has(id))return cache.get(id);const p=packageReference(request.store,ref,key,metadata);requireThat(p.entry.gameId===request.gameId&&p.entry.minLauncherCode<=1,'Пакет требует другую версию SKADI.');validatePackage(p,progress);cache.set(id,p);return p;}
  const pack=load(request.reference,request.action!=='install'),previous=[];
  function add(ref){const p=load(ref);if((p.plan.contextId===pack.plan.contextId||request.gameId==='pgr')&&!previous.some(v=>v.entry.sha256===p.entry.sha256)&&p.entry.sha256!==pack.entry.sha256)previous.push(p);}
  const catalog=cachedCatalog(request.store,request.reference.catalogHash,key);
  for(const p of catalog.value.packages.filter(p=>p.gameId===request.gameId&&(p.contextId===pack.plan.contextId||request.gameId==='pgr')))add({catalogHash:request.reference.catalogHash,packageHash:p.sha256});
  const guard=gameGuard(root,pack,previous,request.action==='inspect');
  const tx=new Transaction({root,store:request.store,gameId:request.gameId,guard,progress});
  const stateFile=under(tx.home,'state.json');if(fs.existsSync(stateFile)){const state=readJson(stateFile,32*1024*1024);requireThat(state.gameId===request.gameId&&path.resolve(state.root)===root,'Состояние относится к другой игре.');if(state.reference)add(state.reference);}
  const pending=tx.pending();if(pending){requireThat(pending.reference.packageHash===pack.entry.sha256||request.action==='inspect','Сначала восстановите прерванную установку.');if(pending.previousReference)add(pending.previousReference);}
  const adapter=new (request.gameId==='pgr'?PgrAdapter:CznAdapter)({pack,previous,root,store:request.store,transaction:tx,progress});
  await guard(true);
  if(request.action==='recover'){requireThat(pending&&pending.reference.packageHash===pack.entry.sha256,'Неверный пакет восстановления.');await tx.recover(j=>adapter.validateJournal(j));}
  else if(request.action!=='inspect'){requireThat(!pending,'Сначала восстановите прерванную установку.');const prepared=await adapter.prepare(request.action);await guard(true);await tx.run(prepared);}
  const finalAdapter=request.action==='inspect'?adapter:new (request.gameId==='pgr'?PgrAdapter:CznAdapter)({pack,previous,root,store:request.store,transaction:tx,progress});
  const result=await finalAdapter.inspect();await guard(true);return {...result,format:'skadi-operation-result-v1',operationId:request.id,contextId:pack.plan.contextId};
}
try{emit({type:'result',value:await main()});}catch(e){emit({type:'result',value:{format:'skadi-operation-result-v1',error:e.message,details:e.stack}});process.exitCode=1;}
