import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {discoverAndroidSerial} from './store.mjs'
const [action,pack,readyFile]=process.argv.slice(2),here=path.dirname(fileURLToPath(import.meta.url)),program=path.resolve(here,'../..');
const emit=o=>process.stdout.write(JSON.stringify(o)+'\n');const messages=[];
try{
 if(!['inspect','install','restore','recover'].includes(action)||!pack||!readyFile)throw Error('Неверная USB-операция.');
 for(let i=0;i<200&&!fs.existsSync(readyFile);i++)await new Promise(r=>setTimeout(r,25));const ready=JSON.parse(fs.readFileSync(readyFile,'utf8'));if(ready.parentPid!==process.ppid)throw Error('Рабочий процесс потерял связь с SKADI.');
 const envelope=JSON.parse(fs.readFileSync(path.join(pack,'package.json'),'utf8'));if(envelope.format!=='skadi-usb-package-v1'||envelope.gameId!=='czn')throw Error('Неизвестный Android-пакет.');
 const adb=path.join(program,'usb/platform-tools/adb.exe'),serial=discoverAndroidSerial(adb),root='/sdcard/Android/data/com.smilegate.chaoszero.stove.google/files/gameres';
 console.log=(...parts)=>{const text=parts.join(' ');messages.push(text);emit({type:'progress',text});};console.error=console.log;
 process.argv=[process.execPath,path.join(here,'installer.mjs'),action==='inspect'?'check':action==='install'?'install':'uninstall','android',root,path.join(pack,'payload'),adb,serial];
 await import('./installer.mjs');if(process.exitCode)throw Error(messages.at(-1)||'USB-операция не завершена.');
 if(action!=='inspect'){process.argv[2]='check';await import('./installer.mjs?final');if(process.exitCode)throw Error(messages.at(-1)||'Проверка результата не прошла.');}
 const installed=messages.some(x=>x.includes('Перевод установлен, откат доступен.')),plan=JSON.parse(fs.readFileSync(path.join(pack,'payload/install-plan.json'),'utf8'));
 emit({type:'result',value:{checked:true,compatible:true,installed,canRollback:installed,needsRecovery:false,files:plan.chunks.length,version:envelope.version,serial,message:action==='restore'||action==='recover'?'USB-установка отменена; оригинальные файлы восстановлены.':''}});
}catch(e){emit({type:'result',value:{error:e.message,needsRecovery:messages.some(x=>x.startsWith('Установка прервана:'))}});process.exitCode=1;}
