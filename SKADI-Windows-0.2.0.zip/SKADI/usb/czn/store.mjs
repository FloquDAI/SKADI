import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { spawnSync } from 'node:child_process'

// Google-supported Windows USB compatibility mode, scoped to this launcher.
const adbEnvironment = () => process.platform === 'win32' ? { ...process.env, ADB_USB_LEGACY: '1' } : process.env

const SAFE = /^[A-Za-z0-9._/-]+$/
function validateRelative(relative) {
  if (!relative || !SAFE.test(relative) || relative.startsWith('/') ||
      relative.split('/').some(part => part === '' || part === '.' || part === '..'))
    throw new Error(`Недопустимый путь: ${relative}`)
  return relative
}
export const sha256 = buffer => crypto.createHash('sha256').update(buffer).digest('hex')
export function hashLocalFile(file) {
  const hash=crypto.createHash('sha256'),fd=fs.openSync(file,'r'),block=Buffer.alloc(1024*1024)
  try { let count; do { count=fs.readSync(fd,block,0,block.length,null); if(count) hash.update(block.subarray(0,count)) } while(count) }
  finally { fs.closeSync(fd) }
  return hash.digest('hex')
}

export class LocalStore {
  constructor(root) {
    this.root=path.resolve(root)
    if(path.basename(this.root).toLowerCase()!=='gameres') throw new Error('Нужна папка gameres установленной игры.')
  }
  full(relative) {
    const full=path.resolve(this.root,...validateRelative(relative).split('/'))
    if(!full.startsWith(this.root+path.sep)) throw new Error('Путь вышел за пределы gameres')
    return full
  }
  exists(relative) { return fs.existsSync(this.full(relative)) }
  size(relative) { return fs.statSync(this.full(relative)).size }
  hash(relative) { return hashLocalFile(this.full(relative)) }
  read(relative) { return fs.readFileSync(this.full(relative)) }
  readRange(relative,offset,length) {
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(length)||length<0) throw new Error('Неверный диапазон')
    const out=Buffer.alloc(length),fd=fs.openSync(this.full(relative),'r')
    try { let done=0; while(done<length) { const count=fs.readSync(fd,out,done,length-done,offset+done); if(!count) throw new Error('Неполное чтение'); done+=count } }
    finally { fs.closeSync(fd) }
    return out
  }
  writeRange(relative,offset,data) {
    if(!Number.isSafeInteger(offset)||offset<0||!Buffer.isBuffer(data)||!data.length) throw new Error('Неверная запись')
    const fd=fs.openSync(this.full(relative),'r+')
    try { let done=0; while(done<data.length) done+=fs.writeSync(fd,data,done,data.length-done,offset+done); fs.fsyncSync(fd) }
    finally { fs.closeSync(fd) }
  }
  mkdir(relative) { fs.mkdirSync(this.full(relative),{recursive:true}) }
  writeAtomic(relative,data) {
    if(!Buffer.isBuffer(data)) data=Buffer.from(data)
    const final=this.full(relative)
    fs.mkdirSync(path.dirname(final),{recursive:true})
    const temporary=`${final}.czn-new-${crypto.randomUUID()}`
    const fd=fs.openSync(temporary,'wx')
    try { fs.writeFileSync(fd,data); fs.fsyncSync(fd) } finally { fs.closeSync(fd) }
    fs.renameSync(temporary,final)
    if(this.hash(relative)!==sha256(data)) throw new Error(`Контроль записи не прошёл: ${relative}`)
  }
  stopGame() {
    if(process.platform!=='win32') return
    const result=spawnSync('tasklist',['/FO','CSV','/NH'],{encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024})
    if(result.status===0 && /(^|\r?\n)"(?:ChaosZeroNightmare|ucldr_ChaosZeroNightmare[^\"]*)\.exe"/i.test(result.stdout))
      throw new Error('Игра открыта. Закройте её и повторите установку.')
  }
}

function shellQuote(value) { return `'${String(value).replaceAll("'", "'\\''")}'` }
export class AdbStore {
  constructor(adbPath,serial,root) {
    this.adb=path.resolve(adbPath)
    if(!fs.existsSync(this.adb)) throw new Error(`ADB не найден: ${this.adb}`)
    if(!/^[A-Za-z0-9._:-]+$/.test(serial)) throw new Error('Недопустимый идентификатор телефона')
    this.serial=serial
    this.root=root.replace(/\/$/,'')
    if(this.root!=='/sdcard/Android/data/com.smilegate.chaoszero.stove.google/files/gameres')
      throw new Error('Неверная папка Android-игры')
  }
  full(relative) { return `${this.root}/${validateRelative(relative)}` }
  run(args,maxBuffer=1024*1024) {
    const result=spawnSync(this.adb,['-s',this.serial,...args],{encoding:null,windowsHide:true,maxBuffer,timeout:300000,env:adbEnvironment()})
    if(result.error||result.status!==0) throw new Error(`ADB: ${(result.stderr||Buffer.alloc(0)).toString('utf8').trim()||result.error?.message||result.status}`)
    return result.stdout
  }
  shell(command) { return this.run(['shell',command],1024*1024).toString('utf8').trim() }
  exists(relative) { return this.shell(`test -f ${shellQuote(this.full(relative))} && echo yes || echo no`)==='yes' }
  size(relative) { const n=Number(this.shell(`stat -c %s ${shellQuote(this.full(relative))}`)); if(!Number.isSafeInteger(n)) throw new Error('Неверный размер Android-файла'); return n }
  hash(relative) {
    const value=this.shell(`sha256sum ${shellQuote(this.full(relative))}`)
    const found=/^([0-9a-f]{64})\s/.exec(value)
    if(!found) throw new Error(`Android не вернул SHA-256: ${relative}`)
    return found[1]
  }
  read(relative) { return this.run(['exec-out',`cat ${shellQuote(this.full(relative))}`],this.size(relative)+1024*1024) }
  readRange(relative,offset,length) {
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(length)||length<0) throw new Error('Неверный диапазон Android')
    const output=this.run(['exec-out',`dd if=${shellQuote(this.full(relative))} bs=65536 skip=${offset} count=${length} iflag=skip_bytes,count_bytes status=none`],length+1024*1024)
    if(output.length!==length) throw new Error(`Телефон вернул неполный блок: ${relative}`)
    return output
  }
  pushBuffer(remote,data) {
    const temporaryDir=fs.mkdtempSync(path.join(os.tmpdir(),'czn-ssra-'))
    const local=path.join(temporaryDir,'block.bin')
    try {
      fs.writeFileSync(local,data)
      this.run(['push',local,remote])
      const value=this.shell(`sha256sum ${shellQuote(remote)}`)
      if(!value.startsWith(sha256(data))) throw new Error('Переданный на телефон блок не прошёл SHA-256')
    } finally {
      try { fs.unlinkSync(local); fs.rmdirSync(temporaryDir) } catch { /* keep private temporary bytes for recovery */ }
    }
  }
  writeRange(relative,offset,data) {
    this.stopGame();
    if(!Number.isSafeInteger(offset)||offset<0||!Buffer.isBuffer(data)||!data.length) throw new Error('Неверная запись Android')
    const remote=`/data/local/tmp/czn-ssra-${crypto.randomUUID()}.bin`
    try {
      this.pushBuffer(remote,data)
      this.shell(`dd if=${shellQuote(remote)} of=${shellQuote(this.full(relative))} bs=65536 seek=${offset} oflag=seek_bytes conv=notrunc,fsync status=none`)
    } finally { try { this.shell(`rm -f ${shellQuote(remote)}`) } catch { /* temporary file is isolated */ } }
  }
  mkdir(relative) { this.shell(`mkdir -p ${shellQuote(this.full(relative))}`) }
  writeAtomic(relative,data) {
    this.stopGame();
    if(!Buffer.isBuffer(data)) data=Buffer.from(data)
    const final=this.full(relative),temporary=`${final}.czn-new-${crypto.randomUUID()}`
    const directory=path.posix.dirname(final)
    this.shell(`mkdir -p ${shellQuote(directory)}`)
    try {
      this.pushBuffer(temporary,data)
      this.shell(`mv ${shellQuote(temporary)} ${shellQuote(final)} && sync`)
      if(this.hash(relative)!==sha256(data)) throw new Error(`Контроль Android-записи не прошёл: ${relative}`)
    } finally { try { this.shell(`rm -f ${shellQuote(temporary)}`) } catch { /* keep final file */ } }
  }
  stopGame() {
    const p='com.smilegate.chaoszero.stove.google';
    if(this.shell(`pidof ${p} || true`))throw new Error('Закройте CZN через настройки приложений телефона и повторите.');
    const names=this.shell('ps -A -o NAME').split(/\r?\n/).map(x=>x.trim());
    if(names[0]!=='NAME'||names.some(n=>n===p||n.startsWith(p+':')))throw new Error('Не удалось подтвердить, что CZN закрыта.');
    if(this.contextHashes&&!this.contextHashes.includes(this.hash('manifest.ssra')))throw new Error('Игра обновилась во время операции; файлы сохранены.');
  }
}

export function discoverAndroidSerial(adbPath) {
  const adb=path.resolve(adbPath),options={encoding:'utf8',windowsHide:true,maxBuffer:1024*1024,timeout:15000,env:adbEnvironment()}
  const enumerate=()=>{
    const result=spawnSync(adb,['devices','-l'],options)
    if(result.error||result.status!==0) throw new Error('Не удалось запустить проверку USB-подключения. Проверьте комплект лаунчера.')
    return result.stdout.split(/\r?\n/).map(x=>x.trim().split(/\s+/)).filter(x=>x.length>1&&['device','offline','unauthorized'].includes(x[1]))
  }
  let devices=enumerate()
  // An existing ADB server may have been started with the incompatible backend.
  // Restart only when it reports no devices, never during an active connection.
  if(devices.length===0&&process.platform==='win32') {
    for(const command of ['kill-server','start-server']) {
      const result=spawnSync(adb,[command],options)
      if(result.error||result.status!==0) throw new Error('Не удалось восстановить USB-подключение. Переподключите телефон и повторите проверку.')
    }
    devices=enumerate()
  }
  const online=devices.filter(x=>x[1]==='device')
  if(online.length===0) {
    if(devices.some(x=>x[1]==='unauthorized')) throw new Error('Разблокируйте телефон и разрешите отладку по USB в появившемся запросе, затем нажмите «Проверить».')
    if(devices.some(x=>x[1]==='offline')) throw new Error('Телефон подключён, но не отвечает. Переподключите кабель и повторите проверку.')
    throw new Error('Телефон не найден. Подключите один телефон по USB, разблокируйте его и включите отладку по USB.')
  }
  if(online.length!==1) throw new Error('Подключено несколько телефонов. Оставьте один и повторите проверку.')
  return online[0][0]
}
