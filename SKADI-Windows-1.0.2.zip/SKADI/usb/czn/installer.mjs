// Public SSRA v4 patcher. The package contains pre-encrypted resources; this
// program has no database key and never rewrites text outside verified slots.
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import zlib from 'node:zlib'
import { LocalStore, AdbStore, discoverAndroidSerial, sha256 } from './store.mjs'
import { xxhash64 } from './xxhash64.mjs'

try {
const [action,platform,location,payloadArg,adbArg,serialArg]=process.argv.slice(2)
if(!['check','install','uninstall'].includes(action)||!['pc','android'].includes(platform)||!location||!payloadArg)
  throw new Error('Usage: node installer.mjs <check|install|uninstall> <pc|android> <gameres|Android-gameres> <payload> [adb] [serial]')
const payloadRoot=path.resolve(payloadArg)
const planBytes=fs.readFileSync(path.join(payloadRoot,'install-plan.json'))
const plan=JSON.parse(planBytes.toString('utf8'))
const payload=JSON.parse(fs.readFileSync(path.join(payloadRoot,'manifest.json'),'utf8'))
if(plan.format!=='czn-ssra-safe-install-plan-v1'||payload.format!=='czn-ssra-keyless-payload-v1'||
   plan.packageVersion!==payload.packageVersion||plan.sourceManifestSha256!==payload.sourceManifestSha256||
   !Array.isArray(plan.chunks)||plan.resourceCount!==payload.resources.length)
  throw new Error('Пакет перевода повреждён или несовместим.')
const targetManifest=fs.readFileSync(path.join(payloadRoot,'manifest.target.ssra'))
if(sha256(targetManifest)!==plan.targetManifestSha256) throw new Error('Контрольная сумма манифеста пакета не совпала.')
const store=platform==='pc' ? new LocalStore(location) :
  new AdbStore(adbArg,serialArg||discoverAndroidSerial(adbArg),location)
if(platform==='android') {store.contextHashes=[plan.sourceManifestSha256,plan.targetManifestSha256];store.stopGame();}
const planSha256=sha256(planBytes)
const legacyRoot=`.czn_ru_ssra_${plan.sourceManifestSha256.slice(0,12)}_backup`
let backupRoot=`.czn_ru_ssra_${plan.sourceManifestSha256.slice(0,12)}_${planSha256.slice(0,16)}_backup`
if(store.exists(`${legacyRoot}/state.json`)){
 try{const old=JSON.parse(store.read(`${legacyRoot}/state.json`).toString('utf8'));if(old.format!=='czn-ssra-rollback-state-v1'||!/^([0-9a-f]{64})$/.test(old.planSha256||'')||old.planSha256===planSha256&&old.packageVersion===plan.packageVersion&&old.sourceManifestSha256===plan.sourceManifestSha256)backupRoot=legacyRoot;}catch{backupRoot=legacyRoot;}
}
const stateFile=`${backupRoot}/state.json`
const sourceManifestBackup=`${backupRoot}/manifest.original.ssra`
const sourceEtagBackup=`${backupRoot}/manifest.original.etag`
const chunks=plan.chunks
const targetManifestXxh64=xxhash64(targetManifest).toString()
const etagPath='manifest.ssra.etag'
const resourceNames=new Set(payload.resources.map(item=>item.name))
if(resourceNames.size!==payload.resources.length||chunks.length<1) throw new Error('Дублирующиеся или пустые ресурсы пакета.')
const safeChunk=/^(?:lang_en_b\d{2}_0|base_b\d{2}_0|base_large_[a-z0-9_]+)\.ssrc$/
for(const chunk of chunks) {
  if(!safeChunk.test(chunk.name)||!Number.isSafeInteger(chunk.diskBytes)||chunk.diskBytes<=16||
     chunk.bodyBytes!==chunk.diskBytes-16||!Array.isArray(chunk.patches)||!chunk.patches.length||
     !/^[0-9a-f]{64}$/.test(chunk.sourceSha256)||!/^[0-9a-f]{64}$/.test(chunk.targetSha256)||
     !/^[0-9a-f]{16}$/.test(chunk.sourceXxh64)||!/^[0-9a-f]{16}$/.test(chunk.targetXxh64))
    throw new Error(`Недопустимый план архива: ${chunk.name}`)
  for(const patch of chunk.patches) {
    if(!resourceNames.has(patch.name)||!/^stored\/\d{2}\.zst$/.test(patch.targetStoredFile)||
       !Number.isSafeInteger(patch.fileOffset)||patch.fileOffset<0||
       !Number.isSafeInteger(patch.targetBytes)||patch.targetBytes<1||
       patch.targetBytes>patch.sourceBytes||patch.fileOffset+patch.sourceBytes>chunk.bodyBytes)
      throw new Error(`Недопустимый блок патча: ${patch.name}`)
  }
}
const chunkPath=chunk=>`chunks/${chunk.name}`
const backupPath=(chunkIndex,patchIndex)=>`${backupRoot}/blocks/${String(chunkIndex).padStart(2,'0')}-${String(patchIndex).padStart(2,'0')}.bin`
function parseEtag(bytes) {
  const value=bytes.toString('utf8')
  const newline=value.includes('\r\n')?'\r\n':'\n'
  const lines=value.split(newline)
  if(lines.at(-1)==='') lines.pop()
  if(lines.length!==4||!/^https:\/\/.+\/manifest\.ssra\.zst$/.test(lines[0])||
     !/^"[0-9a-f]{32}"$/.test(lines[1])||!/^[0-9]+$/.test(lines[2])||
     !/^[0-9]+$/.test(lines[3])||value.includes('\0'))
    throw new Error('Неизвестный формат кэша манифеста; файлы игры не менялись.')
  return {lines,newline,trailing:value.endsWith(newline)}
}
function sourceManifestBytes(state) {
  if(state&&store.exists(sourceManifestBackup)) {
    const bytes=store.read(sourceManifestBackup)
    if(sha256(bytes)!==plan.sourceManifestSha256) throw new Error('Исходный манифест для отката повреждён.')
    return bytes
  }
  const bytes=store.read('manifest.ssra')
  if(sha256(bytes)!==plan.sourceManifestSha256) throw new Error('Не найден исходный манифест для проверки кэша.')
  return bytes
}
function expectedEtag(state) {
  const source=sourceManifestBytes(state)
  return {sourceHash:xxhash64(source).toString(),sourceBytes:source.length,
    targetHash:targetManifestXxh64,targetBytes:targetManifest.length}
}
function etagStatus(state) {
  if(!store.exists(etagPath)) return 'unknown'
  const {lines}=parseEtag(store.read(etagPath)),expected=expectedEtag(state)
  if(lines[2]===expected.sourceHash&&Number(lines[3])===expected.sourceBytes) return 'source'
  if(lines[2]===expected.targetHash&&Number(lines[3])===expected.targetBytes) return 'target'
  return 'unknown'
}
function setEtag(state,kind) {
  const current=etagStatus(state)
  if(current==='unknown') throw new Error('Кэш манифеста изменился; запись остановлена.')
  if(current===kind) return
  const expected=expectedEtag(state),source=store.read(etagPath),parsed=parseEtag(source)
  parsed.lines[2]=kind==='target'?expected.targetHash:expected.sourceHash
  parsed.lines[3]=String(kind==='target'?expected.targetBytes:expected.sourceBytes)
  const bytes=Buffer.from(parsed.lines.join(parsed.newline)+(parsed.trailing?parsed.newline:''),'utf8')
  store.writeAtomic(etagPath,bytes)
  if(etagStatus(state)!==kind) throw new Error('Кэш манифеста после записи не прошёл проверку.')
}
function targetBlob(patch) {
  const file=path.resolve(payloadRoot,patch.targetStoredFile)
  if(!file.startsWith(payloadRoot+path.sep)) throw new Error('Путь пакета вышел за пределы папки.')
  const bytes=fs.readFileSync(file)
  if(bytes.length!==patch.targetBytes||sha256(bytes)!==patch.targetStoredSha256)
    throw new Error(`Блок пакета повреждён: ${patch.name}`)
  return bytes
}
function checkPayload() {
  for(const item of payload.resources) {
    const chunk=chunks.find(x=>x.patches.some(p=>p.name===item.name))
    const patch=chunk?.patches.find(p=>p.name===item.name)
    if(!patch||item.targetStoredSha256!==patch.targetStoredSha256||item.targetStoredBytes!==patch.targetBytes)
      throw new Error(`Ресурс не включён в план: ${item.name}`)
    const decoded=zlib.zstdDecompressSync(targetBlob(patch))
    if(decoded.length!==item.targetPlainBytes||sha256(decoded)!==item.targetPlainSha256)
      throw new Error(`Ресурс не прошёл распаковку: ${item.name}`)
  }
}
function chunkStatus(chunk) {
  const relative=chunkPath(chunk)
  if(!store.exists(relative)||store.size(relative)!==chunk.diskBytes) return 'unknown'
  const hash=store.hash(relative)
  return hash===chunk.sourceSha256?'source':hash===chunk.targetSha256?'target':'unknown'
}
function inspect() {
  if(!store.exists('manifest.ssra')) throw new Error('Манифест игры не найден.')
  const manifest=store.hash('manifest.ssra')
  const manifestStatus=manifest===plan.sourceManifestSha256?'source':
    manifest===plan.targetManifestSha256?'target':'unknown'
  const statuses=chunks.map(chunkStatus)
  const source=statuses.filter(x=>x==='source').length
  const target=statuses.filter(x=>x==='target').length
  const unknown=statuses.length-source-target
  console.log(`Манифест: ${manifestStatus}; архивы: исходных ${source}, переведённых ${target}, неизвестных ${unknown}.`)
  return {manifestStatus,statuses,source,target,unknown}
}
function loadState() {
  if(!store.exists(stateFile)) return null
  const state=JSON.parse(store.read(stateFile).toString('utf8'))
  if(state.format!=='czn-ssra-rollback-state-v1'||state.planSha256!==planSha256||
     state.sourceManifestSha256!==plan.sourceManifestSha256||!Array.isArray(state.backups))
    throw new Error('Журнал отката не соответствует этому пакету; файлы игры не менялись.')
  return state
}
function saveState(state) { store.writeAtomic(stateFile,Buffer.from(`${JSON.stringify(state,null,2)}\n`)) }
function validateBackups(state) {
  if(!store.exists(sourceManifestBackup)||store.hash(sourceManifestBackup)!==plan.sourceManifestSha256)
    throw new Error('Оригинальный манифест в журнале недоступен.')
  const expected=chunks.reduce((n,c)=>n+c.patches.length,0)
  if(state.backups.length!==expected) throw new Error('Журнал отката неполный.')
  for(const info of state.backups) {
    if(!store.exists(info.file)||store.size(info.file)!==info.bytes||store.hash(info.file)!==info.sha256)
      throw new Error(`Исходный блок для отката повреждён: ${info.file}`)
  }
  if(state.sourceEtagSha256 && (!store.exists(sourceEtagBackup)||store.hash(sourceEtagBackup)!==state.sourceEtagSha256))
    throw new Error('Исходный кэш манифеста для отката повреждён.')
}
function prepareBackup() {
  if(etagStatus(null)!=='source') throw new Error('Кэш манифеста не соответствует исходной игре.')
  store.mkdir(`${backupRoot}/blocks`)
  store.writeAtomic(sourceManifestBackup,store.read('manifest.ssra'))
  const sourceEtag=store.read(etagPath)
  store.writeAtomic(sourceEtagBackup,sourceEtag)
  const backups=[]
  for(let ci=0;ci<chunks.length;ci++) {
    const chunk=chunks[ci]
    for(let pi=0;pi<chunk.patches.length;pi++) {
      const patch=chunk.patches[pi]
      const original=store.readRange(chunkPath(chunk),patch.fileOffset,patch.targetBytes)
      const file=backupPath(ci,pi)
      store.writeAtomic(file,original)
      backups.push({file,chunkIndex:ci,patchIndex:pi,bytes:original.length,sha256:sha256(original)})
    }
  }
  const state={format:'czn-ssra-rollback-state-v1',packageVersion:plan.packageVersion,
    planSha256,sourceManifestSha256:plan.sourceManifestSha256,
    phase:'prepared',ownerHost:os.hostname(),ownerPid:process.pid,
    startedAt:new Date().toISOString(),sourceEtagSha256:sha256(sourceEtag),backups}
  saveState(state)
  validateBackups(state)
  return state
}
function sourceTail(chunk) {
  const data=Buffer.alloc(8)
  data.writeBigUInt64LE(BigInt(`0x${chunk.sourceXxh64}`))
  return data
}
function targetTail(chunk) {
  const data=Buffer.alloc(8)
  data.writeBigUInt64LE(BigInt(`0x${chunk.targetXxh64}`))
  return data
}
function backupBytes(state,ci,pi) {
  const entry=state.backups.find(x=>x.chunkIndex===ci&&x.patchIndex===pi)
  if(!entry) throw new Error('Не найден блок отката.')
  const bytes=store.read(entry.file)
  if(bytes.length!==entry.bytes||sha256(bytes)!==entry.sha256) throw new Error('Блок отката изменился.')
  return bytes
}
function virtualOriginalHash(chunk,ci,state) {
  const hash=crypto.createHash('sha256')
  const segment=32*1024*1024
  for(let offset=0;offset<chunk.diskBytes;offset+=segment) {
    const length=Math.min(segment,chunk.diskBytes-offset)
    const block=store.readRange(chunkPath(chunk),offset,length)
    for(let pi=0;pi<chunk.patches.length;pi++) {
      const patch=chunk.patches[pi]
      const backup=backupBytes(state,ci,pi)
      const left=Math.max(offset,patch.fileOffset),right=Math.min(offset+length,patch.fileOffset+backup.length)
      if(right>left) backup.copy(block,left-offset,left-patch.fileOffset,right-patch.fileOffset)
    }
    const tail=chunk.bodyBytes+8
    if(tail<offset+length&&tail+8>offset) {
      const bytes=sourceTail(chunk),left=Math.max(offset,tail),right=Math.min(offset+length,tail+8)
      bytes.copy(block,left-offset,left-tail,right-tail)
    }
    hash.update(block)
  }
  return hash.digest('hex')
}
function restore(state,observation) {
  validateBackups(state)
  if(observation.manifestStatus==='unknown') throw new Error('Манифест обновлён другой программой; автоматический откат остановлен.')
  // Verify that all bytes outside our edits are still the original game's bytes.
  for(let ci=0;ci<chunks.length;ci++) {
    const chunk=chunks[ci]
    if(observation.statuses[ci]!=='source'&&virtualOriginalHash(chunk,ci,state)!==chunk.sourceSha256)
      throw new Error(`Игра изменила ${chunk.name}; журнал сохранён, автоматический откат остановлен.`)
  }
  for(let ci=0;ci<chunks.length;ci++) {
    const chunk=chunks[ci]
    if(observation.statuses[ci]==='source') continue
    for(let pi=0;pi<chunk.patches.length;pi++) {
      const patch=chunk.patches[pi]
      store.writeRange(chunkPath(chunk),patch.fileOffset,backupBytes(state,ci,pi))
    }
    store.writeRange(chunkPath(chunk),chunk.bodyBytes+8,sourceTail(chunk))
    if(store.hash(chunkPath(chunk))!==chunk.sourceSha256) throw new Error(`Не удалось вернуть ${chunk.name}.`)
    console.log(`Восстановлен ${chunk.name}`)
  }
  if(observation.manifestStatus==='target') store.writeAtomic('manifest.ssra',store.read(sourceManifestBackup))
  if(store.hash('manifest.ssra')!==plan.sourceManifestSha256) throw new Error('Оригинальный манифест не восстановлен.')
  if(state.sourceEtagSha256) store.writeAtomic(etagPath,store.read(sourceEtagBackup))
  else setEtag(state,'source') // Recover installations made before the cache fix.
  if(etagStatus(state)!=='source') throw new Error('Исходный кэш манифеста не восстановлен.')
  state.phase='uninstalled'; saveState(state)
}
function apply(state) {
  state.phase='installing';state.ownerHost=os.hostname();state.ownerPid=process.pid;saveState(state)
  for(const chunk of chunks) {
    const relative=chunkPath(chunk)
    for(const patch of chunk.patches) {
      const bytes=targetBlob(patch)
      store.writeRange(relative,patch.fileOffset,bytes)
      if(sha256(store.readRange(relative,patch.fileOffset,bytes.length))!==patch.targetStoredSha256)
        throw new Error(`После записи блок ${patch.name} не совпал.`)
    }
    store.writeRange(relative,chunk.bodyBytes+8,targetTail(chunk))
    if(store.hash(relative)!==chunk.targetSha256) throw new Error(`Контроль архива ${chunk.name} после записи не прошёл.`)
    console.log(`Готов ${chunk.name}`)
  }
  store.writeAtomic('manifest.ssra',targetManifest)
  setEtag(state,'target')
  const result=inspect()
  if(result.manifestStatus!=='target'||result.target!==chunks.length||result.unknown||etagStatus(state)!=='target')
    throw new Error('Итоговая проверка игры не прошла.')
  state.phase='installed';saveState(state)
  console.log('ГОТОВО: перевод установлен; все файлы и откат проверены.')
}

try {
  console.log(`CZN ${plan.packageVersion} — ${platform==='pc'?'ПК':'Android'}`)
  if(action!=='check') store.stopGame()
  const observed=inspect()
  let state=loadState()
  if(action==='check') {
    if(observed.manifestStatus==='target'&&observed.target===chunks.length&&state) {validateBackups(state);if(etagStatus(state)!=='target') throw new Error('Кэш манифеста не соответствует установленному переводу.');console.log('Перевод установлен, откат доступен.');}
    else if(observed.manifestStatus==='source'&&observed.source===chunks.length) {if(etagStatus(state)!=='source') throw new Error('Кэш манифеста не соответствует исходной игре.');console.log('Игра готова к установке перевода.')}
    else throw new Error('Состояние игры требует восстановления или новой совместимой сборки.')
  } else if(action==='uninstall') {
    if(!state) throw new Error('Журнал отката не найден; файлы игры не менялись.')
    if(observed.manifestStatus==='source'&&observed.source===chunks.length&&etagStatus(state)==='source') console.log('Перевод уже удалён.')
    else {restore(state,observed);console.log('ГОТОВО: оригинальные файлы игры восстановлены.')}
  } else {
    checkPayload()
    if(observed.manifestStatus==='target'&&observed.target===chunks.length) {
      if(!state) throw new Error('Перевод найден без журнала отката; установка остановлена.')
      validateBackups(state);if(etagStatus(state)!=='target') throw new Error('Кэш манифеста не соответствует переводу.');console.log('Перевод уже установлен и проверен.')
    } else {
      if(state&&!(observed.manifestStatus==='source'&&observed.source===chunks.length)) {
        if(state.phase==='installing'&&state.ownerHost===os.hostname()&&state.ownerPid!==process.pid) {
          try { process.kill(state.ownerPid,0); throw new Error('Другой запущенный лаунчер ещё устанавливает перевод.') }
          catch(error) { if(error.code!=='ESRCH') throw error }
        }
        restore(state,observed)
      }
      const clean=inspect()
      if(clean.manifestStatus!=='source'||clean.source!==chunks.length) throw new Error('Исходная игра не совпала с этой версией пакета.')
      state=prepareBackup()
      try {apply(state)}
      catch(error) {
        console.error(`Установка прервана: ${error.message}`)
        try { restore(state,inspect()); console.error('Исходные файлы автоматически восстановлены.') }
        catch(recovery) {console.error(`Восстановление не завершено: ${recovery.message}. Сохраните папку отката и повторите запуск.`)}
        throw error
      }
    }
  }
} catch(error) { console.error(`ОШИБКА: ${error.message}`);process.exitCode=1 }
} catch(error) { console.error(`ОШИБКА: ${error.message}`);process.exitCode=1 }
