import fs from 'node:fs';import path from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';
import {discoverAndroidSerial,AdbStore,sha256} from './store.mjs';
import {CardTransition} from './transition.mjs';
import {profileIndex,profileId,applyCardProfile,ensureProfileBlob} from '../../core/czn-profiles.mjs';
const [action,pack,readyFile]=process.argv.slice(2),here=path.dirname(fileURLToPath(import.meta.url)),program=path.resolve(here,'../..');
const emit=o=>process.stdout.write(JSON.stringify(o)+'\n'),messages=[];let pending=false,rolledBack=false;
try{
 if(!['inspect','install','restore','recover'].includes(action)||!pack||!readyFile)throw Error('Неверная USB-операция.');
 for(let i=0;i<200&&!fs.existsSync(readyFile);i++)await new Promise(r=>setTimeout(r,25));const ready=JSON.parse(fs.readFileSync(readyFile,'utf8'));if(ready.parentPid!==process.ppid)throw Error('Рабочий процесс потерял связь с SKADI.');
 const chosen=profileId(ready),index=profileIndex(),envelope=JSON.parse(fs.readFileSync(path.join(pack,'package.json'),'utf8'));if(envelope.format!=='skadi-usb-package-v1'||envelope.gameId!=='czn')throw Error('Неизвестный Android-пакет.');
 const originalPlanBytes=fs.readFileSync(path.join(pack,'payload/install-plan.json')),original=JSON.parse(originalPlanBytes),metadata=JSON.parse(fs.readFileSync(path.join(pack,'payload/manifest.json'),'utf8'));
 if(sha256(originalPlanBytes)!==index.basePlanSha256)throw Error('Для этой версии игры ещё нет выбранного варианта карт.');
 const adb=path.join(program,'usb/platform-tools/adb.exe'),serial=discoverAndroidSerial(adb),root='/sdcard/Android/data/com.smilegate.chaoszero.stove.google/files/gameres',store=new AdbStore(adb,serial,root);
 const known=new Map([[original.targetManifestSha256,'cards-7'],...index.profiles.map(p=>[p.targetManifestSha256,p.id])]);
 store.contextHashes=[original.sourceManifestSha256,...known.keys()];
 const marker='.skadi_czn_card_transition.json',stages=new Map();let invocation=0;
 console.log=(...parts)=>{const text=parts.join(' ');messages.push(text);emit({type:'progress',text});};console.error=console.log;
 const loadJournal=()=>{
  if(!store.exists(marker))return null;const size=store.size(marker);if(size>8192)throw Error('Повреждён журнал установки CZN.');const j=JSON.parse(store.read(marker).toString('utf8'));
  if(j.format!=='skadi-czn-usb-profile-transition-v1'||j.planSha256!==index.basePlanSha256||j.serial!==serial||!['prepared','restoring','originals','installing','committed','complete'].includes(j.phase))throw Error('Журнал относится к другому пакету или телефону.');profileId({profileId:j.next});if(j.previous!==null)profileId({profileId:j.previous});return j;
 };

 const currentId=()=>known.get(store.hash('manifest.ssra'))||null;
 const view=id=>{
  const base={plan:{gameId:'czn',legacyPlanSha256:index.basePlanSha256,sourceManifestSha256:original.sourceManifestSha256,targetManifest:'payload/manifest.target.ssra'},czn:original,cznMetadata:metadata,root:pack,profileCacheStore:path.resolve(path.dirname(readyFile),'../..'),payloadPrefix:'payload/',ref:{},entry:{}};
  return applyCardProfile(base,id);
 };
 const profileCacheStore=path.resolve(path.dirname(readyFile),'../..');
 const stage=async id=>{
  if(id==='cards-7')return path.join(pack,'payload');if(stages.has(id))return stages.get(id);
  await ensureProfileBlob(profileCacheStore,id,text=>emit({type:'progress',text}));
  const v=view(id),out=path.join(path.dirname(readyFile),'czn-profile-'+id);fs.mkdirSync(path.join(out,'stored'),{recursive:true});
  const put=(relative,bytes)=>{const file=path.join(out,relative);fs.writeFileSync(file,bytes);if(sha256(fs.readFileSync(file))!==sha256(bytes))throw Error('Не удалось подготовить вариант карт.');};
  // Keep the exact pinned plan bytes: backup identities must match the Android APK.
  const planFile=path.join(program,'core/czn-card-profiles',id+'.plan.json');put('install-plan.json',fs.readFileSync(planFile));put('manifest.json',Buffer.from(JSON.stringify(v.cznMetadata)));put('manifest.target.ssra',v.readPayload('payload/manifest.target.ssra'));
  for(const r of v.cznMetadata.resources)put(r.targetStoredFile,v.readPayload('payload/'+r.targetStoredFile));stages.set(id,out);return out;
 };
 const invoke=async(mode,id)=>{
  const start=messages.length;process.exitCode=0;process.argv=[process.execPath,path.join(here,'installer.mjs'),mode,'android',root,await stage(id),adb,serial];
  await import(pathToFileURL(path.join(here,'installer.mjs')).href+'?skadi='+ ++invocation);
  if(process.exitCode)throw Error(messages.at(-1)||'USB-операция не завершена.');return messages.slice(start);
 };
 const cleanSource=()=>{
  if(store.hash('manifest.ssra')!==original.sourceManifestSha256)return false;
  for(const c of original.chunks)if(store.size('chunks/'+c.name)!==c.diskBytes||store.hash('chunks/'+c.name)!==c.sourceSha256)return false;return true;
 };
 const tx=new CardTransition({read:loadJournal,write:j=>{store.writeAtomic(marker,Buffer.from(JSON.stringify(j)+'\n'));pending=j.phase!=='complete';},planSha256:index.basePlanSha256,serial,current:currentId,cleanSource,sourceManifest:()=>store.hash('manifest.ssra')===original.sourceManifestSha256,invoke,stage});pending=tx.pending;
 let actual=currentId();
 if(pending&&action!=='recover'&&action!=='inspect')throw Error('Сначала восстановите прерванную USB-установку.');
 if(action==='recover'&&pending)actual=await tx.recover();
 else if(action==='install')actual=await tx.install(chosen);
 else if(action==='restore'||action==='recover'){
  if(actual)await invoke('uninstall',actual);else if(!cleanSource())await invoke('uninstall',chosen);
  await invoke('check',chosen);actual=null;
 }else await invoke('check',actual||chosen);
 process.exitCode=0;
 emit({type:'result',value:{checked:true,compatible:true,installed:actual===chosen,canRollback:actual!==null,needsRecovery:pending,files:original.chunks.length,version:envelope.version,serial,cardProfileId:actual||'original',selectedProfileId:chosen,message:pending?'Нужна проверка прерванной установки.':action==='restore'||action==='recover'?'Предыдущее состояние восстановлено.':actual&&actual!==chosen?'Доступен выбранный вариант перевода карт.':''}});
}catch(e){emit({type:'result',value:{error:e.message,needsRecovery:pending||!(rolledBack||e.rolledBack)&&messages.some(x=>x.startsWith('Установка прервана:'))}});process.exitCode=1;}
