export class CardTransition {
 constructor(port){this.p=port;this.j=port.read();if(this.j){const j=this.j;if(j.format!=='skadi-czn-usb-profile-transition-v1'||j.planSha256!==port.planSha256||j.serial!==port.serial||!['prepared','restoring','originals','installing','committed','complete'].includes(j.phase)||!(j.previous===null||/^cards-[0-7]$/.test(j.previous||''))||!/^cards-[0-7]$/.test(j.next||''))throw Error('Журнал относится к другому пакету или телефону.');}}
 get pending(){return !!this.j&&this.j.phase!=='complete';}
 save(phase){this.j.phase=phase;this.p.write(this.j);this.p.fault?.(phase);}
 async recover(){
  const actual=this.p.current(),j=this.j;if(!this.pending)throw Error('Прерванных установок нет.');
  if(j.phase==='committed'&&actual===j.next){await this.p.invoke('check',j.next);this.save('complete');return j.next;}
  if(j.previous&&actual===j.previous){try{await this.p.invoke('check',actual);this.save('complete');return actual;}catch{await this.p.invoke('uninstall',actual);}}
  else if(!this.p.cleanSource()){if(actual!==j.next&&!this.p.sourceManifest())throw Error('Версия игры изменилась. Резервная копия сохранена.');await this.p.invoke('uninstall',j.next);}
  if(j.previous){await this.p.invoke('install',j.previous);await this.p.invoke('check',j.previous);}else await this.p.invoke('check',j.next);
  this.save('complete');return j.previous;
 }
 async install(chosen){
  if(this.pending)throw Error('Сначала восстановите прерванную USB-установку.');if(!/^cards-[0-7]$/.test(chosen||''))throw Error('Неверный выбор перевода карт.');
  const actual=this.p.current();if(!actual&&!this.p.sourceManifest())throw Error('Эта версия игры несовместима с пакетом перевода.');
  await this.p.invoke('check',actual||chosen);await this.p.stage(chosen);
  this.j={format:'skadi-czn-usb-profile-transition-v1',planSha256:this.p.planSha256,serial:this.p.serial,previous:actual,next:chosen,phase:'prepared'};this.save('prepared');
  try{if(actual&&actual!==chosen){this.save('restoring');await this.p.invoke('uninstall',actual);this.save('originals');}this.save('installing');await this.p.invoke('install',chosen);await this.p.invoke('check',chosen);this.save('committed');this.save('complete');return chosen;}
  catch(error){if(error?.simulatedDeath)throw error;try{await this.recover();}catch(recovery){throw Error('Установка прервана: резервные копии сохранены; требуется восстановление. '+recovery.message);}const failure=Error('Установка прервана: предыдущее состояние восстановлено. '+error.message);failure.rolledBack=true;throw failure;}
 }
}
