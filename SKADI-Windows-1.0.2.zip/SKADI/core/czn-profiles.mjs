import fs from 'node:fs';import path from 'node:path';import zlib from 'node:zlib';import {fileURLToPath} from 'node:url';
import {hashBytes,under,requireThat} from './safe.mjs';
import {checkedBlob,downloadProfileBlob} from './profile-download.mjs';
import {PROFILE_INDEX_SHA256} from './czn-profile-pin.mjs';
const home=path.join(path.dirname(fileURLToPath(import.meta.url)),'czn-card-profiles');
let saved;
export function profileId(ref){const id=ref?.profileId??'cards-7';requireThat(/^cards-[0-7]$/.test(id),'Неверный выбор перевода карт.');return id;}
export function profileIndex(){if(saved)return saved;const bytes=fs.readFileSync(under(home,'index.json'));requireThat(bytes.length<256*1024&&hashBytes(bytes)===PROFILE_INDEX_SHA256,'Данные выбора карт повреждены.');const index=JSON.parse(bytes);requireThat(index.format==='skadi-czn-card-profiles-v1'&&index.profiles.length===7,'Неизвестный набор вариантов карт.');saved=index;return saved;}
export function decodeDelta(base,compressed){
 const delta=zlib.inflateSync(compressed,{maxOutputLength:128*1024*1024});requireThat(delta.length>=16&&delta.toString('ascii',0,4)==='CZPD'&&delta.readUInt32BE(4)===base.length,'Повреждён блок варианта карт.');
 const length=delta.readUInt32BE(8),count=delta.readUInt32BE(12);requireThat(length>0&&length<=64*1024*1024&&count<=1000000,'Вариант карт слишком большой.');const out=Buffer.alloc(length);let offset=16,written=0;
 for(let i=0;i<count;i++){
  requireThat(offset+5<=delta.length,'Неполный блок варианта карт.');const type=delta[offset++],a=delta.readUInt32BE(offset);offset+=4;
  if(type===0){requireThat(offset+4<=delta.length,'Неполный блок варианта карт.');const n=delta.readUInt32BE(offset);offset+=4;requireThat(n>0&&a+n<=base.length&&written+n<=out.length,'Диапазон варианта карт вышел за файл.');base.copy(out,written,a,a+n);written+=n;}
  else{requireThat(type===1&&a>0&&offset+a<=delta.length&&written+a<=out.length,'Недопустимый блок варианта карт.');delta.copy(out,written,offset,offset+a);offset+=a;written+=a;}
 }
 requireThat(offset===delta.length&&written===out.length,'Вариант карт неполный.');return out;
}
function asset(id,suffix,expected){const bytes=fs.readFileSync(under(home,id+suffix));requireThat(bytes.length<=32*1024*1024&&hashBytes(bytes)===expected,'Данные выбора карт повреждены.');return bytes;}
export function applyCardProfile(base,id){
 profileId({profileId:id});if(id==='cards-7')return {...base,ref:{...base.ref,profileId:id}};
 requireThat(base.plan.gameId==='czn','Выбор карт доступен только для CZN.');const index=profileIndex(),row=index.profiles.find(p=>p.id===id);
 requireThat(row&&base.plan.legacyPlanSha256===index.basePlanSha256&&base.plan.sourceManifestSha256===index.sourceManifestSha256,'Для этой версии игры ещё нет выбранного варианта карт.');
 const planBytes=asset(id,'.plan.json',row.planSha256),plan=JSON.parse(planBytes),baseManifest=fs.readFileSync(under(base.root,base.plan.targetManifest));requireThat(hashBytes(baseManifest)===index.baseManifestSha256,'Исходный манифест пакета повреждён.');
 const manifest=decodeDelta(baseManifest,asset(id,'.manifest.delta',row.manifestDeltaSha256));requireThat(hashBytes(manifest)===row.targetManifestSha256&&plan.targetManifestSha256===row.targetManifestSha256&&plan.cardProfileId===id&&plan.sourceManifestSha256===index.sourceManifestSha256,'Манифест варианта карт повреждён.');
 const metadata=structuredClone(base.cznMetadata);metadata.packageVersion=plan.packageVersion;const resource=metadata.resources.find(r=>r.name===row.resource.name);requireThat(resource,'Ресурс карт отсутствует.');Object.assign(resource,row.resource);
 let blob;const readPayload=relative=>{
  if(relative===base.plan.targetManifest)return manifest;
  if(relative===(base.payloadPrefix||'czn/')+index.mainStoredFile){if(!blob){const original=fs.readFileSync(under(base.root,relative));requireThat(hashBytes(original)===index.baseBlobSha256,'Исходный ресурс карт повреждён.');blob=decodeDelta(original,checkedBlob(base.profileCacheStore,row));requireThat(blob.length===row.resource.targetStoredBytes&&hashBytes(blob)===row.resource.targetStoredSha256,'Ресурс выбранных карт повреждён.');const decoded=zlib.zstdDecompressSync(blob,{maxOutputLength:128*1024*1024});requireThat(decoded.length===row.resource.targetPlainBytes&&hashBytes(decoded)===row.resource.targetPlainSha256,'Ресурс выбранных карт не прошёл проверку.');}return blob;}
  return fs.readFileSync(under(base.root,relative));
 };
 return {...base,ref:{...base.ref,profileId:id},plan:{...base.plan,legacyPlanSha256:row.planSha256,targetManifestSha256:row.targetManifestSha256},czn:plan,cznMetadata:metadata,readPayload};
}
export function allProfileViews(base){const index=profileIndex();if(base.plan.gameId!=='czn'||base.plan.legacyPlanSha256!==index.basePlanSha256)return [base];return ['cards-7',...index.profiles.map(p=>p.id)].map(id=>applyCardProfile(base,id));}

export async function ensureProfileBlob(store,id,progress=()=>{}){profileId({profileId:id});if(id==='cards-7')return;const row=profileIndex().profiles.find(p=>p.id===id);requireThat(row,'Неверный вариант перевода карт.');await downloadProfileBlob(store,row,progress);}
