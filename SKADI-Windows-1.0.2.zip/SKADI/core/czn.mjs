import fs from 'node:fs'
import path from 'node:path'
import {xxhash64} from './xxhash64.mjs'
import {under,readJson,writeJson,atomic,hashBytes,hashFile,fingerprint,equal,expect,readRange,virtualHash,rangesUnion,requireThat} from './safe.mjs'
import {cznLegacyOriginals} from './legacy.mjs'

const fp=b=>({exists:true,bytes:b.length,sha256:hashBytes(b)})
const tail=value=>{const b=Buffer.alloc(8);b.writeBigUInt64LE(BigInt('0x'+value));return b}
const chunkPath=c=>'chunks/'+c.name
export function parseEtag(bytes){
  requireThat(bytes.length<=8192,'Неизвестный кэш манифеста.');const value=bytes.toString('utf8'),newline=value.includes('\r\n')?'\r\n':'\n',lines=value.split(newline);if(lines.at(-1)==='')lines.pop()
  requireThat(lines.length===4&&/^https:\/\/.+\/manifest\.ssra\.zst$/.test(lines[0])&&/^"[a-f0-9]{32}"$/.test(lines[1])&&/^[0-9]{1,20}$/.test(lines[2])&&/^[0-9]{1,12}$/.test(lines[3])&&!value.includes('\0'),'Неизвестный формат кэша манифеста.');return {lines,newline,trailing:value.endsWith(newline)}
}
export function etagFor(bytes,manifest){const p=parseEtag(bytes);p.lines[2]=xxhash64(manifest).toString();p.lines[3]=String(manifest.length);return Buffer.from(p.lines.join(p.newline)+(p.trailing?p.newline:''))}
export class CznAdapter {
  constructor({pack,previous=[],root,store,transaction,progress=()=>{}}){this.pack=pack;this.plan=pack.czn;this.previous=previous.filter(p=>p.plan.gameId==='czn');this.root=root;this.store=store;this.tx=transaction;this.progress=progress;const file=under(transaction.home,'state.json');this.state=fs.existsSync(file)?readJson(file,32*1024*1024):null;this.sourceManifest=null;this.sourceEtag=null;this.originalRanges=[]}
  candidates(){return [this.pack,...this.previous]}
  acceptsChunk(c,actual){return actual.exists&&actual.bytes===c.diskBytes&&(actual.sha256===c.sourceSha256||this.candidates().some(p=>p.czn.chunks.some(x=>x.name===c.name&&x.sourceSha256===c.sourceSha256&&x.diskBytes===c.diskBytes&&x.targetSha256===actual.sha256)))}
  ownCanonical(){
    const rows=[];if(!this.state||this.state.format!=='skadi-czn-state-v1')return rows;
    requireThat(path.resolve(this.state.root)===path.resolve(this.root),'Состояние CZN относится к другой папке.')
    for(const r of this.state.ranges||[]){
      requireThat(/^chunks\/(?:lang_en_b\d{2}_0|base_b\d{2}_0|base_large_[a-z0-9_]+)\.ssrc$/.test(r.path)&&/^[a-f0-9]{64}$/.test(r.sourceSha256)&&Number.isSafeInteger(r.offset)&&r.offset>=0&&Number.isSafeInteger(r.length)&&r.length>0&&r.length<=128*1024*1024&&/^[a-f0-9]{64}$/.test(r.sha256),'Повреждены ссылки оригинальных блоков CZN.')
      const file=under(this.tx.home,'canonical/'+r.sha256+'.bin'),bytes=fs.readFileSync(file);requireThat(bytes.length===r.length&&hashBytes(bytes)===r.sha256,'Исходный блок CZN в резервной копии повреждён.');rows.push({...r,bytes})
    }
    if(this.state.contextId===this.pack.plan.contextId){
      const manifest=under(this.tx.home,'canonical/'+this.pack.plan.contextId+'.manifest');if(fs.existsSync(manifest)&&hashFile(manifest)===this.pack.plan.contextId)this.sourceManifest=fs.readFileSync(manifest)
      if(this.state.sourceEtagSha256){const file=under(this.tx.home,'canonical/'+this.state.sourceEtagSha256+'.etag');if(fs.existsSync(file)&&hashFile(file)===this.state.sourceEtagSha256)this.sourceEtag=fs.readFileSync(file)}
    }
    return rows
  }
  loadCanonical(){
    let rows=this.ownCanonical();const marker='.czn_ru_ssra_'+this.plan.sourceManifestSha256.slice(0,12)+'_backup/state.json',legacyFile=under(this.root,marker)
    if(fs.existsSync(legacyFile)){
      const state=readJson(legacyFile),candidate=this.candidates().find(p=>p.plan.contextId===this.pack.plan.contextId&&p.plan.legacyPlanSha256===state.planSha256)
      if(candidate){const legacy=cznLegacyOriginals(this.root,candidate);rows.push(...legacy.ranges.map(r=>({...r,length:r.bytes.length})));if(!this.sourceManifest)this.sourceManifest=legacy.sourceManifest;if(!this.sourceEtag)this.sourceEtag=legacy.sourceEtag}
    }
    const current=fs.readFileSync(under(this.root,'manifest.ssra'));if(hashBytes(current)===this.plan.sourceManifestSha256)this.sourceManifest=current
    this.originalRanges=rows;return rows
  }
  canonicalOverlays(c,actual){
    if(actual.sha256===c.sourceSha256)return []
    const rows=this.originalRanges.filter(r=>r.path===chunkPath(c)&&r.sourceSha256===c.sourceSha256).map(r=>({offset:r.offset,bytes:r.bytes}));rows.push({offset:c.bodyBytes+8,bytes:tail(c.sourceXxh64)});return rows
  }
  knownManifests(){return this.candidates().filter(p=>p.plan.contextId===this.pack.plan.contextId).flatMap(p=>[p.czn.sourceManifestSha256,p.czn.targetManifestSha256])}
  validateEtag(bytes,manifest){const p=parseEtag(bytes);requireThat(p.lines[2]===xxhash64(manifest).toString()&&Number(p.lines[3])===manifest.length,'Кэш манифеста не соответствует игре. Завершите обновление игры и повторите проверку.')}
  async inspect(){
    const manifest=fs.readFileSync(under(this.root,'manifest.ssra')),mh=hashBytes(manifest),etag=fs.readFileSync(under(this.root,'manifest.ssra.etag'));this.validateEtag(etag,manifest);let target=0,source=0,unknown=0;
    for(let i=0;i<this.plan.chunks.length;i++){const c=this.plan.chunks[i];this.progress('Проверяю архивы CZN: '+(i+1)+' / '+this.plan.chunks.length);const actual=fingerprint(under(this.root,chunkPath(c)));if(actual.exists&&actual.bytes===c.diskBytes&&actual.sha256===c.targetSha256)target++;else if(actual.exists&&actual.bytes===c.diskBytes&&actual.sha256===c.sourceSha256)source++;else if(!this.acceptsChunk(c,actual))unknown++;}
    let originals=false;
    try{this.loadCanonical();originals=!!this.sourceManifest;
      for(const c of this.plan.chunks){const file=under(this.root,chunkPath(c)),actual=fingerprint(file);if(!this.acceptsChunk(c,actual)||virtualHash(file,this.canonicalOverlays(c,actual))!==c.sourceSha256){originals=false;break;}}
    }catch(error){originals=false;}
    const installed=mh===this.plan.targetManifestSha256&&target===this.plan.chunks.length,compatible=this.knownManifests().includes(mh)&&unknown===0;
    return {gameId:'czn',checked:true,compatible,installed,canRollback:originals,needsRecovery:!!this.tx.pending(),files:this.plan.chunks.length,sourceFiles:source,targetFiles:target,unknownFiles:unknown,packageHash:this.pack.entry.sha256,version:this.pack.entry.version,message:!compatible?'Некоторые файлы не соответствуют пакету. Завершите обновление игры и сохраните отчёт.':!originals&&installed?'Перевод найден; для удаления нужны прежние резервные копии.':''}
  }
  cache(bytes,extension){const hash=hashBytes(bytes),file=under(this.tx.home,'canonical/'+hash+'.'+extension);if(fs.existsSync(file))expect(file,fp(bytes));else atomic(file,bytes);return hash}
  async prepare(action){
    requireThat(['install','restore'].includes(action),'Неверное действие CZN.');this.loadCanonical();requireThat(this.sourceManifest&&hashBytes(this.sourceManifest)===this.plan.sourceManifestSha256,'Не найден проверенный оригинальный манифест CZN. Сохраните старые резервные копии.');
    if(action==='install'&&this.state?.contextId===this.pack.plan.contextId&&this.state.resourceNames){const names=new Set(this.pack.cznMetadata.resources.map(r=>r.name));requireThat(this.state.resourceNames.every(n=>names.has(n)),'Новый пакет не покрывает прежний перевод CZN.')}
    const manifestPath=under(this.root,'manifest.ssra'),currentManifest=fs.readFileSync(manifestPath),beforeManifest=fp(currentManifest),currentEtag=fs.readFileSync(under(this.root,'manifest.ssra.etag'));requireThat(this.knownManifests().includes(beforeManifest.sha256),'Манифест CZN изменился.');this.validateEtag(currentEtag,currentManifest);
    const targetManifest=action==='install'?(this.pack.readPayload?this.pack.readPayload(this.pack.plan.targetManifest):fs.readFileSync(under(this.pack.root,this.pack.plan.targetManifest))):this.sourceManifest,targetEtag=etagFor(currentEtag,targetManifest);if(!this.sourceEtag)this.sourceEtag=etagFor(currentEtag,this.sourceManifest);this.validateEtag(this.sourceEtag,this.sourceManifest);
    const watch=[],ops=[],nextRanges=[];
    for(let ci=0;ci<this.plan.chunks.length;ci++){
      const c=this.plan.chunks[ci],name=chunkPath(c),file=under(this.root,name),before=fingerprint(file);this.progress('Подготавливаю архив CZN: '+(ci+1)+' / '+this.plan.chunks.length);requireThat(this.acceptsChunk(c,before),'Неизвестная версия архива CZN. Файлы не заменены.');const canonical=this.canonicalOverlays(c,before);requireThat(virtualHash(file,canonical)===c.sourceSha256,'Оригиналы CZN не прошли проверку. Сохраните резервные копии.');
      const newEdits=c.patches.map(p=>({offset:p.fileOffset,length:p.targetBytes,patch:p}));newEdits.push({offset:c.bodyBytes+8,length:8,tail:true});
      const oldEdits=this.originalRanges.filter(r=>r.path===name&&r.sourceSha256===c.sourceSha256).map(r=>({offset:r.offset,length:r.bytes.length}));const union=rangesUnion([...oldEdits,...newEdits]);
      const staged=[];
      for(const r of union){
        const actual=readRange(file,r.offset,r.length),clean=Buffer.from(actual);
        for(const overlay of canonical){const left=Math.max(r.offset,overlay.offset),right=Math.min(r.offset+r.length,overlay.offset+overlay.bytes.length);if(left<right)overlay.bytes.copy(clean,left-r.offset,left-overlay.offset,right-overlay.offset)}
        const desired=Buffer.from(clean);
        if(action==='install')for(const edit of newEdits){const bytes=edit.tail?tail(c.targetXxh64):this.pack.readPayload?this.pack.readPayload('czn/'+edit.patch.targetStoredFile):fs.readFileSync(under(this.pack.root,'czn/'+edit.patch.targetStoredFile)),left=Math.max(r.offset,edit.offset),right=Math.min(r.offset+r.length,edit.offset+bytes.length);if(left<right)bytes.copy(desired,left-r.offset,left-edit.offset,right-edit.offset)}
        staged.push({offset:r.offset,bytes:desired});if(!actual.equals(desired))ops.push({kind:'range',path:name,offset:r.offset,before:fp(actual),after:fp(desired),afterBytes:desired,order:0});
      }
      const after={exists:true,bytes:c.diskBytes,sha256:action==='install'?c.targetSha256:c.sourceSha256};requireThat(virtualHash(file,staged)===after.sha256,'Подготовленный перевод CZN не совпал с подписанным архивом.');watch.push({path:name,before,after});
      for(const e of newEdits){if(e.tail)continue;let bytes=readRange(file,e.offset,e.length);for(const overlay of canonical){const left=Math.max(e.offset,overlay.offset),right=Math.min(e.offset+e.length,overlay.offset+overlay.bytes.length);if(left<right)overlay.bytes.copy(bytes,left-e.offset,left-overlay.offset,right-overlay.offset)}const hash=this.cache(bytes,'bin');nextRanges.push({path:name,sourceSha256:c.sourceSha256,offset:e.offset,length:bytes.length,sha256:hash})}
    }
    for(const [name,beforeBytes,afterBytes,order] of [['manifest.ssra',currentManifest,targetManifest,100],['manifest.ssra.etag',currentEtag,targetEtag,101]]){const before=fp(beforeBytes),after=fp(afterBytes);watch.push({path:name,before,after});if(!equal(before,after))ops.push({kind:'file',path:name,before,after,afterBytes,order})}
    const manifestFile=under(this.tx.home,'canonical/'+this.plan.sourceManifestSha256+'.manifest');if(fs.existsSync(manifestFile))expect(manifestFile,fp(this.sourceManifest));else atomic(manifestFile,this.sourceManifest);const sourceEtagSha256=this.cache(this.sourceEtag,'etag');
    const afterState={format:'skadi-czn-state-v1',gameId:'czn',root:this.root,contextId:this.pack.plan.contextId,reference:this.pack.ref,ranges:nextRanges,sourceEtagSha256,resourceNames:this.pack.cznMetadata.resources.map(r=>r.name),installed:action==='install'};
    return {action,contextId:this.pack.plan.contextId,reference:this.pack.ref,previousReference:this.state?.reference||null,watch,ops,beforeState:this.state,afterState};
  }
  validateJournal(j){
    requireThat(j.contextId===this.pack.plan.contextId&&['install','restore'].includes(j.action),'Журнал относится к другой версии CZN.');const chunks=new Map(this.plan.chunks.map(c=>[chunkPath(c),c])),allowed=new Map();
    for(const p of this.candidates())for(const c of p.czn.chunks){if(!chunks.has(chunkPath(c))||chunks.get(chunkPath(c)).sourceSha256!==c.sourceSha256)continue;let rows=allowed.get(chunkPath(c));if(!rows)allowed.set(chunkPath(c),rows=[]);for(const r of c.patches)rows.push({offset:r.fileOffset,length:r.targetBytes});rows.push({offset:c.bodyBytes+8,length:8})}
    requireThat(j.watch.length===chunks.size+2,'Неполный журнал CZN.');const paths=new Set();
    for(const w of j.watch){requireThat(!paths.has(w.path),'Повторяющаяся запись журнала.');paths.add(w.path);if(chunks.has(w.path)){const c=chunks.get(w.path);requireThat(this.acceptsChunk(c,w.before)&&w.after.exists&&w.after.bytes===c.diskBytes&&w.after.sha256===(j.action==='install'?c.targetSha256:c.sourceSha256),'Неверный отпечаток архива в журнале.');}else{
      requireThat(['manifest.ssra','manifest.ssra.etag'].includes(w.path),'Неверный файл журнала CZN.');
      requireThat(w.before.exists&&w.after.exists&&Number.isSafeInteger(w.before.bytes)&&Number.isSafeInteger(w.after.bytes),'Неверный размер манифеста.');
      if(w.path==='manifest.ssra')requireThat(this.knownManifests().includes(w.before.sha256)&&w.after.sha256===(j.action==='install'?this.plan.targetManifestSha256:this.plan.sourceManifestSha256),'Манифест журнала не соответствует подписанному пакету.');
      else requireThat(w.before.bytes<=8192&&w.after.bytes<=8192,'Слишком большой кэш манифеста.');
    }}
    const used=new Map(),fileOps=new Set();
    for(const op of j.ops){requireThat(paths.has(op.path),'Изменение вне подписанного плана CZN.');if(op.kind==='range'){
      requireThat(op.order===0&&op.before.exists&&op.after.exists&&Number.isSafeInteger(op.offset)&&Number.isSafeInteger(op.length)&&op.length>0&&chunks.has(op.path)&&rangesUnion(allowed.get(op.path)).some(r=>op.offset>=r.offset&&op.offset+op.length<=r.offset+r.length)&&op.length===op.before.bytes&&op.length===op.after.bytes,'Неверный диапазон журнала CZN.');
      const rows=used.get(op.path)||[];requireThat(rows.every(r=>op.offset+op.length<=r.offset||r.offset+r.length<=op.offset),'Пересекающиеся операции журнала CZN.');rows.push(op);used.set(op.path,rows);
    }else{const w=j.watch.find(w=>w.path===op.path);requireThat(op.kind==='file'&&!fileOps.has(op.path)&&['manifest.ssra','manifest.ssra.etag'].includes(op.path)&&op.order===(op.path==='manifest.ssra'?100:101)&&equal(w.before,op.before)&&equal(w.after,op.after),'Неверная замена манифеста CZN.');fileOps.add(op.path);}}
    for(const w of j.watch)if(!equal(w.before,w.after))requireThat(used.has(w.path)||fileOps.has(w.path),'В журнале пропущено изменение CZN.');
  }
}
