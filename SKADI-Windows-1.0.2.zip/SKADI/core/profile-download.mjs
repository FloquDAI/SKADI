import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import {under,regular,hashFile,hashBytes,requireThat} from './safe.mjs';

export const PROFILE_BASE='https://github.com/FloquDAI/SKADI/releases/download/v1.0.2/';
const hosts=new Set(['github.com','release-assets.githubusercontent.com','objects.githubusercontent.com','github-releases.githubusercontent.com']);
async function connect(address,offset){
  let current=new URL(address);
  for(let i=0;i<6;i++){
    requireThat(current.protocol==='https:'&&hosts.has(current.hostname)&&(!current.port||current.port==='443')&&!current.username&&!current.password&&!current.hash,'Недопустимое перенаправление загрузки.');
    const response=await new Promise((resolve,reject)=>{
      const request=https.get(current,{headers:{'Accept-Encoding':'identity','User-Agent':'SKADI/1.0.2',...(offset?{Range:'bytes='+offset+'-'}:{})}},resolve);
      request.setTimeout(30000,()=>request.destroy(Error('Загрузка прервана. Повторите — скачивание продолжится.')));request.on('error',reject);
    });
    if([301,302,303,307,308].includes(response.statusCode)){const location=response.headers.location;response.resume();requireThat(location,'Сервер не указал адрес загрузки.');current=new URL(location,current);continue;}
    return response;
  }
  throw Error('Слишком много перенаправлений загрузки.');
}
export function blobPath(store,hash){requireThat(/^[a-f0-9]{64}$/.test(hash),'Неверный отпечаток варианта карт.');return under(store,'card-profiles/'+hash+'.blob.delta');}
export function checkedBlob(store,row){
  const file=blobPath(store,row.blobDeltaSha256);requireThat(regular(file).size===row.blobDeltaBytes,'Данные выбора карт повреждены. Повторите загрузку варианта.');const bytes=fs.readFileSync(file);requireThat(bytes.length===row.blobDeltaBytes&&hashBytes(bytes)===row.blobDeltaSha256,'Данные выбора карт повреждены. Повторите загрузку варианта.');return bytes;
}
// The production caller supplies an APK/program-pinned row, never an arbitrary URL.
export async function downloadProfileBlob(store,row,progress=()=>{},open=connect){
  requireThat(/^cards-[0-6]$/.test(row.id)&&/^[a-f0-9]{64}$/.test(row.blobDeltaSha256)&&Number.isSafeInteger(row.blobDeltaBytes)&&row.blobDeltaBytes>0&&row.blobDeltaBytes<=32*1024*1024,'Неверный вариант перевода карт.');
  const target=blobPath(store,row.blobDeltaSha256),part=target+'.part',size=row.blobDeltaBytes;
  fs.mkdirSync(path.dirname(target),{recursive:true});
  if(fs.existsSync(target)&&regular(target).size===size&&hashFile(target)===row.blobDeltaSha256)return target;
  let offset=fs.existsSync(part)?regular(part).size:0;
  if(offset>size){fs.unlinkSync(part);offset=0;}
  if(offset<size){
    progress('Скачиваю выбранный перевод карт…');
    const response=await open(PROFILE_BASE+'CZN-133-'+row.id+'.blob.delta',offset);
    try{
      requireThat([200,206].includes(response.statusCode),'Загрузка выбранного перевода карт недоступна (HTTP '+response.statusCode+').');
      if(response.statusCode===206){const range=String(response.headers['content-range']||'').match(/^bytes (\d+)-(\d+)\/(\d+)$/);requireThat(range&&Number(range[1])===offset&&Number(range[2])===size-1&&Number(range[3])===size,'Сервер вернул неверный диапазон загрузки.');}
      else offset=0;
      const fd=fs.openSync(part,offset?'a':'w');let total=offset,last=0;
      try{for await(const bytes of response){requireThat(bytes.length<=size-total,'Сервер вернул лишние данные.');fs.writeFileSync(fd,bytes);total+=bytes.length;if(Date.now()-last>250){progress('Скачиваю выбранный перевод карт: '+Math.floor(total*100/size)+'%');last=Date.now();}}fs.fsyncSync(fd);requireThat(total===size,'Загрузка прервана. Повторите — скачивание продолжится.');}
      finally{fs.closeSync(fd);}
    }finally{response.destroy();}
  }
  if(!fs.existsSync(part)||regular(part).size!==size||hashFile(part)!==row.blobDeltaSha256){if(fs.existsSync(part))fs.unlinkSync(part);throw Error('Контрольная сумма варианта карт не совпала. Повторите скачивание.');}
  fs.renameSync(part,target);checkedBlob(store,row);return target;
}
